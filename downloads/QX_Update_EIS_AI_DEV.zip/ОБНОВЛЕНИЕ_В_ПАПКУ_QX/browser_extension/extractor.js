/* TenderNotes: локальное извлечение видимого текста из страницы закупки.
   Никаких запросов на чужие серверы: только DOM активной вкладки.
   СБИС, ЕИС и прочие площадки: общие подписи + специальные правила.
*/
window.__tendernotesExtractPage = function () {
  'use strict';
  const u = new URL(location.href);
  const hostname = u.hostname.toLowerCase();
  const isEis = hostname.endsWith('zakupki.gov.ru');
  const isSbis = hostname.endsWith('sbis.ru') || hostname.endsWith('tensor.ru') || hostname.endsWith('online.sbis.ru');
  const source = isEis ? 'ЕИС' : (isSbis ? 'СБИС' : hostname);
  const root = document.body || document.documentElement;
  const text = String(root.innerText || '').replace(/\u00a0/g, ' ').slice(0, 140000);
  const lines = text.split(/\n+/).map(s => s.trim()).filter(Boolean).slice(0, 6000);
  const simple = text.replace(/[\t ]+/g, ' ').replace(/\n{3,}/g, '\n\n');
  const cut = (v, n) => (String(v || '').replace(/\s+/g, ' ').trim().slice(0, n));
  const find = (re) => {const m = simple.match(re);return m ? cut(m[1], 600) : '';};
  const ds = '(\\d{1,2}[.\\/-]\\d{1,2}[.\\/-]\\d{2,4})';
  const dt = '(\\d{1,2}[.\\/-]\\d{1,2}[.\\/-]\\d{2,4}(?:\\s+\\d{1,2}:\\d{2})?)';
  const currency = '([0-9][0-9 \\u00a0\\u202f.,]*[0-9]|[0-9])';
  const label = (names, valueRx, nextLines=3) => {
    const rx = new RegExp('(?:'+names+')\\s*[:：\\-]?\\s*'+valueRx, 'i');
    let m = simple.match(rx);
    if (m && m[1]) return cut(m[1], 600);
    const test = new RegExp('^(?:'+names+')\\s*[:：\\-]?\\s*$', 'i');
    for (let i=0;i<lines.length;i++) {
      if (test.test(lines[i])) {
        const w = lines.slice(i+1,i+1+nextLines).join(' ');
        m = w.match(new RegExp('^\\s*'+valueRx, 'i'));
        if (m && m[1]) return cut(m[1], 600);
      }
    }
    return '';
  };
  const firstSelector = (list) => {
    for (const sel of list) {
      try { const element = document.querySelector(sel);
        const txt = element && (element.innerText || element.textContent);
        if (txt && txt.trim()) return cut(txt, 850);
      } catch (_) {}
    }
    return '';
  };
  const prefer = (...vals) => vals.find(v => v && v.trim()) || '';
  const dates = (names) => label(names, '('+dt.slice(1,-1)+')', 3);
  // Ссылки ЕИС передают regNumber (19 символов для 44-ФЗ, 11 для 223-ФЗ).
  const qsReg = u.searchParams.get('regNumber') || u.searchParams.get('purchaseNumber') || '';
  let number = /^\d{11}$|^\d{19}$/.test(qsReg) ? qsReg : '';
  if (!number) {
    const a = document.querySelector('[data-testid="purchaseNumber"], [data-qa="purchase-number"]');
    const fromDOM = a && a.textContent || '';
    const m = fromDOM.match(/\b(?:\d{19}|\d{11})\b/);
    if (m) number = m[0];
  }
  if (!number) number = find(/(?:Номер\s+(?:закупки|извещения|процедуры)|№\s*(?:извещения|закупки)?)[\s№:]*((?:\d{19}|\d{11})\b)/i);
  if (!number) number = (text.match(/\b\d{19}\b/) || text.match(/\b\d{11}\b/) || [''])[0];
  if (!number) {
    const m = text.match(/(?:Номер\s*(?:тендера|процедуры|лота)|№)\s*[:№]?\s*([A-Za-zА-Яа-я0-9][A-Za-zА-Яа-я0-9_-]{4,58})/i);
    if (m) number = m[1];
  }

  const h1 = firstSelector(['main h1','[class*="PurchaseTitle"]','[class*="purchaseTitle"]','[class*="tender-title"]','h1']);
  const descriptiveLine = lines.find(line => /^(?:Аукцион в электронной форме|Поставка\s|Оказание услуг|Выполнение работ)/i.test(line) && line.length > 25) || '';
  const title = prefer(
    label('Наименование\\s+(?:объекта\\s+)?закупки|Предмет\\s+закупки|Название\\s+закупки', '([^\\n]{10,350})'),
    descriptiveLine, h1, cut(document.title.replace(/\s*[-|—]\s*(СБИС|ЕИС|Закупки).*$/i, ''), 500)
  );
  let customer = prefer(
    label('Наименование\\s+заказчика|Заказчик|Организация-заказчик', '([^\\n]{5,350})'),
    firstSelector(['[data-testid="customerName"]','[class*="customerName"]','[class*="customer-name"]'])
  );
  // Универсальное чтение: подписи иногда на предыдущей строке/в соседних ячейках.
  if (customer.length < 5) {
    // Для кратких сводных карточек (например, представленной пользователем)
    // организация иногда идёт строкой сразу под регионом, без подписи.
    const index = lines.findIndex(l => /\b\d{19}\b|\b\d{11}\b/.test(l));
    if (index >= 0 && index < 12) {
      const candidate = lines[index + 2] || '';
      if (/(?:ГБУЗ|ГБУ|ФГБУ|ФГБОУ|МБУ|МУП|ООО|АО|ГКУ|ФКУ|ДЗМ|ЦРБ)/i.test(candidate))
        customer = cut(candidate, 550);
    }
  }

  const price = prefer(
    label('Начальная\\s*\\(максимальная\\)\\s*цена\\s*(?:контракта)?|Начальная\\s+цена|НМЦК|Максимальная\\s+цена', '(?:₽|руб\\.?|,\\s*₽)?\\s*'+currency),
    find(new RegExp('(?:НМЦК|Начальная\\s+цена)[^\\n]{0,60}?'+currency, 'i'))
  );
  const unitPrice = label('Цена\\s+за\\s+единицу|Цена\\s+ед\\.?', '(?:₽|руб\\.?|,\\s*₽)?\\s*'+currency);
  const quantity = prefer(
    label('Количество\\s*(?:товара|поставляемого\\s+товара|единиц)?', '(\\d{1,6})\\s*(?:шт\\.?|ед\\.?|штук)?'),
    find(/(?:^|\s)(?:Системн(?:ый|ые)\s+блок(?:и|ов)?|Моноблок(?:и|ов)?|Ноутбук(?:и|ов)?)[^\n]{0,70}?\s(\d{1,6})\s*шт\.?/i)
  );
  const published = dates('Дата\\s+публикации|Опубликовано|Публикация(?:\\s*\\(МСК\\))?|Дата\\s+размещения');
  const deadline = dates('При[её]м\\s+заявок\\s+до|Окончание\\s+при[её]ма\\s+заявок|Дата\\s+и\\s+время\\s+окончания\\s+подачи\\s+заявок|Окончание\\s+подачи\\s+заявок|Дата\\s+окончания\\s+(?:срока\\s+)?подачи\\s+заявок');
  const tradingDate = dates('^Торги|Торги|Дата\\s+торгов|Проведение\\s+торгов');
  const auctionStart = dates('Дата\\s+проведения\\s+аукциона|Дата\\s+начала\\s+аукциона|Начало\\s+аукциона');
  const auctionDate = tradingDate || auctionStart;
  const resultsDate = dates('Дата\\s+(?:подведения\\s+)?итогов|Итоги');
  const place = prefer(label('Место\\s+(?:поставки|исполнения|выполнения\\s+работ)', '([^\\n]{8,400})'), '');
  let region = label('Регион(?:\\s+заказчика)?|Субъект\\s+РФ', '([^\\n]{3,160})');
  if (!region) {
    const i = lines.findIndex(l => /\b\d{19}\b|\b\d{11}\b/.test(l));
    const line = i >= 0 && i < 12 ? (lines[i+1] || '') : '';
    if (/^(Москва|Санкт-Петербург|[А-ЯЁа-яё .-]+(?:область|край|республика|автономный округ))$/i.test(line)) region = line;
  }
  const contact = prefer(label('Контактное\\s+лицо|Контакты', '([^\\n]{5,180})'), '');

  // Multi-lot capture is conservative: only explicitly marked lot/item nodes.
  // Unstructured text cannot prove a position-to-lot relationship.
  const lots = [];
  const lotNodes = typeof document.querySelectorAll === 'function'
    ? Array.from(document.querySelectorAll('[data-lot-number]')).slice(0,200) : [];
  for (const lotNode of lotNodes) {
    const lotId = cut(lotNode.getAttribute('data-lot-number'),120);
    if (!lotId || lots.some(l => l.lot === lotId)) continue;
    const items = [];
    for (const node of [...lotNode.querySelectorAll('[data-item-id]')].slice(0,500)) {
      const sourceId = cut(node.getAttribute('data-item-id'),250);
      const itemTitle = cut(node.getAttribute('data-item-title') || '',1000);
      if (!sourceId || !itemTitle) continue;
      const features = {};
      for (const feature of [...node.querySelectorAll('[data-feature-name][data-feature-value]')].slice(0,300)) {
        const name = cut(feature.getAttribute('data-feature-name'),200);
        if (name) features[name] = cut(feature.getAttribute('data-feature-value'),2000);
      }
      items.push({source_id:sourceId,title:itemTitle,
        quantity:cut(node.getAttribute('data-quantity'),100),
        ktru:cut(node.getAttribute('data-ktru'),200),features,
        documents:[], provenance:{source_url:location.href,lot:lotId,source_id:sourceId,method:'explicit DOM identifiers'}});
    }
    if (items.length) lots.push({lot:lotId,title:cut(lotNode.getAttribute('data-lot-title'),1000),items});
  }
  const delivery = label('Срок(?:и)?\\s+(?:поставки(?:\\s+товара)?|исполнения\\s+контракта)', '([^\\n]{5,600})');
  const payment = label('(?:Порядок|Срок(?:и)?|Условия)\\s+оплаты', '([^\\n]{5,600})');
  const warranty = label('(?:Срок|Условия)\\s+гарантии|Гарантийный\\s+срок', '([^\\n]{5,400})');
  const days = delivery.match(/(?:в\s+течение|не\s+позднее)\s+(\d{1,4})\s+(рабочих|календарных)\s+дн(?:ей|я)?\s+(?:с\s+(?:даты|момента|дня)|после)\s+(?:подписания|заключения)\s+(?:контракта|договора)(?=[\s,.;:)]|$)/i);
  const legal = label('Закон|Законодательство|Закупка\\s+по|Размещение\\s+по', '((?:44|223)\\s*[-–]?\\s*ФЗ)');
  const lawCandidates = [...new Set([legal,...lines.filter(x=>/^(44|223)\s*[-–]?\s*ФЗ$/i.test(x))].filter(Boolean).map(x=>x.replace(/\s/g,'').replace(/–/g,'-').replace(/^(44|223)ФЗ$/i,'$1-ФЗ').toUpperCase()))];
  const law = lawCandidates.length===1?lawCandidates[0]:'';
  const procedure = label('Способ\\s+(?:определения\\s+поставщика(?:\\s*\\([^\\n)]*\\))?|закупки|размещения)', '([^\\n]{5,350})');
  const quotation = /запрос\s+котировок/i.test(procedure) && !/аукцион/i.test(procedure) ? true : null;
  const timezone = value => {
    if(!value)return '';
    const index=simple.indexOf(value);
    if(index<0)return '';
    return (simple.slice(index+value.length,index+value.length+35).match(/^\s*\(?\s*(МСК(?:\s*[+-]\s*\d{1,2}(?::[0-5]\d)?)?|UTC(?:\s*[+-]\s*\d{1,2}(?::[0-5]\d)?)?)\)?/i)||[])[1]||'';
  };
  const dueDate = delivery.match(/(?:не\s+позднее|до)\s+(\d{1,2}\.\d{1,2}\.\d{4})/i);
  let dueOn='';
  if(dueDate){const [d,m,y]=dueDate[1].split('.');dueOn=`${y}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;}
  return {
    number: cut(number,60), url: location.href, source,
    title: cut(title, 900), customer: cut(customer, 550),
    region: cut(region,200), place: cut(place,600),
    law, procedure, is_quotation:quotation,
    deadline_timezone:timezone(deadline), auction_timezone:timezone(auctionDate), results_timezone:timezone(resultsDate),
    published: cut(published,25), deadline: cut(deadline,40),
    auction_date: cut(auctionDate,40), trading_date: cut(tradingDate,40),
    auction_start: cut(auctionStart,40), results_date: cut(resultsDate,40),
    price: cut(price,100), unit_price: cut(unitPrice,100),
    quantity: cut(quantity,50), contact: cut(contact,350),
    payment_terms:cut(payment,600), warranty:cut(warranty,400), due_days:days?Number(days[1]):null, due_unit:days?(days[2].toLowerCase()==='рабочих'?'work':'calendar'):'', due_on:dueOn, delivery_terms:delivery,
    lots, scanned_at: new Date().toISOString()
  };
};
