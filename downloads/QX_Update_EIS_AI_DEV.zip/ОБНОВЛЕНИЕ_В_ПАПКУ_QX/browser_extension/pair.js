// Pairing token stays in a fragment and extension-private storage.
(() => {
  const token=new URLSearchParams(location.hash.slice(1)).get('token');
  if(!token)return;
  history.replaceState(null,'',location.pathname);
  chrome.runtime.sendMessage({type:'qx-pair',token}, result=>{
    const el=document.getElementById('state');
    if(el)el.textContent=result?.ok?'Расширение получило настройки. Вернитесь в QX и проверьте статус подключения.':'Не удалось подключить расширение; повторите из QX.';
  });
})();
