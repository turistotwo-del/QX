// TenderNotes: пользователь вручную запускает считывание в программе.
const ENDPOINT = 'ws://127.0.0.1:18764';
let paired = false;
const pendingImports = new Map();
let socket = null;
let heartbeat = null;
let reconnect = null;
let jobRunning = false;
let activeJobId = null;
const cancelledJobs = new Set();
const pendingDownloads = new Map();
const pendingClaims = new Map();
let claimSequence = 0;
function requestClaim(jobId, url) {
  return new Promise((resolve, reject) => {
    const requestId = String(++claimSequence);
    const timer=setTimeout(() => {
      pendingClaims.delete(requestId);
      reject(new Error('QX не подтвердил резервирование документа; загрузка не начата'));
    }, 12000);
    pendingClaims.set(requestId, decision => {clearTimeout(timer); resolve(decision);});
    if (!socket || socket.readyState!==WebSocket.OPEN) {
      clearTimeout(timer);pendingClaims.delete(requestId);
      reject(new Error('Нет соединения с QX для резервирования документа'));
    } else send({type:'file_claim', id:jobId, request_id:requestId, url});
  });
}

function diagnostic(id, stage, detail={}) {
  // Только техническая структура: без текста страницы, адресов, cookies и файлов.
  const safe={};
  for(const [key, val] of Object.entries(detail || {})) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]{0,40}$/.test(key)) continue;
    if(typeof val==='number' || typeof val==='boolean') safe[key]=val;
    else if(typeof val==='string') safe[key]=val.slice(0,160);
    else if(Array.isArray(val)) safe[key]=val.slice(0,12).map(x=>String(x).slice(0,60));
  }
  send({type:'diagnostic', id, stage, detail:safe});
}
function send(data) {
  if (socket && socket.readyState === WebSocket.OPEN)
    socket.send(JSON.stringify(data));
}
async function connect() {
  if (socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(socket.readyState)) return;
  let token = '';
  try { const config = await fetch(chrome.runtime.getURL('qx_bridge_config.json')).then(r => r.ok ? r.json() : {}); token = String(config.token || ''); } catch (_) {}
  if (!token) { const saved = await chrome.storage.local.get('qx_token'); token = String(saved.qx_token || ''); }
  if (!token) { chrome.action.setBadgeText({text: '?'}); return; }
  if (socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(socket.readyState)) return;
  try { socket = new WebSocket(ENDPOINT); }
  catch (_) { scheduleReconnect(); return; }
  socket.addEventListener('open', () => {
    send({type:'hello', token, version:chrome.runtime.getManifest().version});
    clearInterval(heartbeat);
    heartbeat = setInterval(() => send({type: 'pong'}), 20000);
  });
  socket.addEventListener('message', async event => {
    let cmd;
    try { cmd = JSON.parse(event.data); } catch (_) { return; }
    if (cmd.type === 'paired') { paired=true;chrome.action.setBadgeText({text:'OK'});chrome.action.setBadgeBackgroundColor({color:'#28854e'});return; }
    if (cmd.type === 'file_import_result') { const callback=pendingImports.get(String(cmd.request_id||''));if(callback) {pendingImports.delete(String(cmd.request_id));callback(cmd);}return;}
    if (!paired) return;
    if (cmd.type === 'file_claim_result') {
      const requestId=String(cmd.request_id||'');
      const callback=pendingClaims.get(requestId);
      if (callback) {pendingClaims.delete(requestId);callback(cmd.decision||{action:'busy'});}
      return;
    }
    if (!cmd.id) return;
    if (cmd.type === 'cancel') {
      if (activeJobId !== cmd.id) return;
      cancelledJobs.add(cmd.id);
      diagnostic(cmd.id,'job.cancel_requested',{safe_boundary:'after_current_file'});
      return;
    }
    if (!['capture', 'documents'].includes(cmd.type)) return;
    if (jobRunning) {send({type: 'result', id: cmd.id, error: 'Предыдущая загрузка ещё выполняется'});return;}
    jobRunning = true; activeJobId = cmd.id;
    diagnostic(cmd.id, 'job.start', {command:cmd.type, extension_version:chrome.runtime.getManifest().version});
    try {
      const data = cmd.type === 'capture' ? await captureActiveTab() :
          await documentWorkflow(cmd, state => send({type:'progress', id:cmd.id, message:state}));
      diagnostic(cmd.id, 'job.complete', {command:cmd.type, result_received:true});
      send({type: 'result', id: cmd.id, data});
    } catch (e) {
      diagnostic(cmd.id, 'job.error', {command:cmd.type, error_name:e?.name || 'Error', error_message:String(e?.message||e).slice(0,150)});
      send({type: 'result', id: cmd.id, error: String(e?.message || e)});
    }
    finally { jobRunning = false; activeJobId = null; cancelledJobs.delete(cmd.id); }
  });
  socket.addEventListener('close', () => {
    paired=false;
    clearInterval(heartbeat); heartbeat = null;
    socket = null;
    chrome.action.setBadgeText({text: '!'});
    chrome.action.setBadgeBackgroundColor({color: '#ba582a'});
    scheduleReconnect();
  });
  socket.addEventListener('error', () => {});
}
function scheduleReconnect() {
  if (reconnect) return;
  reconnect = setTimeout(() => {reconnect=null;connect();}, 5000);
}
async function activeTab() {
  const tabs = await chrome.tabs.query({active: true, lastFocusedWindow: true});
  const tab = tabs[0];
  if (!tab || !tab.id || !/^https?:\/\//i.test(tab.url || ''))
    throw new Error('Откройте карточку закупки в обычной вкладке Chrome или Edge.');
  return tab;
}
// Chromium API calls usually reject on navigation errors, but a suspended or
// unresponsive tab can leave executeScript pending indefinitely. Every stage
// gets a bounded deadline and an actionable error. A timed-out operation is
// not retried blindly, so it cannot enqueue duplicate downloads/imports.
function bounded(promise, ms, stage) {
  let timer;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => { timer=setTimeout(() => reject(new Error(
      `Превышено время ожидания ${stage} (${ms} мс). Проверьте вкладку и повторите операцию.`)), ms); })
  ]).finally(() => clearTimeout(timer));
}
async function inject(tabId, file, funcName) {
  await bounded(chrome.scripting.executeScript({target: {tabId}, files: [file]}), 12000, `подключения ${file}`);
  const r = await bounded(chrome.scripting.executeScript({target: {tabId}, func: name =>
    typeof window[name] === 'function' && window[name](), args: [funcName]}), 18000, `чтения ${funcName}`);
  return r?.[0]?.result;
}
async function captureActiveTab() {
  const tab = await activeTab();
  const result = await inject(tab.id, 'extractor.js', '__tendernotesExtractPage');
  if (!result) throw new Error('Не удалось считать страницу.');
  result.url = tab.url || result.url;
  return result;
}
function wait(ms) {return new Promise(r => setTimeout(r, ms));}
async function pageUsable(tabId) {
  // The official EIS often holds "loading" due to long-polling resources.
  // A usable document should not be rejected on tab.status alone.
  try {
    const checks=await chrome.scripting.executeScript({target:{tabId},func:()=>({
      state:document.readyState,
      text:(document.body?.innerText||'').length,
      hasMain:!!document.querySelector('main, .cardMainInfo, .noticeTabBox, [class*="attachment"], [class*="document"]')
    })});
    const r=checks?.[0]?.result;
    return !!r && r.state!=='loading' && (r.text>=300 || (r.text>=120 && r.hasMain));
  } catch (_) {return false;}
}
async function navigate(id, url, progress=()=>{}) {
  try {await chrome.tabs.update(id, {url, active:true});}
  catch (e) {throw new Error('Рабочая вкладка браузера закрыта или недоступна: '+String(e?.message||e));}
  const start=Date.now();let matchingSince=0;
  for (let k=0;k<90;k++) {
    await wait(k<15?500:700);
    let current;
    try {current=await chrome.tabs.get(id);}
    catch (_) {throw new Error('Рабочая вкладка ЕИС была закрыта во время загрузки');}
    const sameNotice = (() => {try {
      const target = new URL(url), loaded = new URL(current.url || '');
      return target.hostname === loaded.hostname && target.pathname === loaded.pathname &&
        (!target.searchParams.get('regNumber') || target.searchParams.get('regNumber') === loaded.searchParams.get('regNumber'));
    } catch(_) {return false;}})();
    if(sameNotice || current.url?.split('#')[0]===url.split('#')[0]) {
      if (!matchingSince) matchingSince=Date.now();
      if (current.status==='complete' || (Date.now()-matchingSince>=1100 && await pageUsable(id))) {
        await wait(650); return;
      }
    }
    if(k===12 || k===35)progress('ЕИС отвечает медленно; проверяю содержимое страницы…');
  }
  throw new Error('Не удалось открыть страницу ЕИС: документ не стал доступен за отведённое время');
}
function expectedEisURL(number) {
  if (/^\d{19}$/.test(number))
    return `https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber=${number}`;
  if (/^\d{11}$/.test(number))
    return `https://zakupki.gov.ru/epz/order/notice/notice223/common-info.html?regNumber=${number}`;
  return '';
}
function fallbackEisDocuments(url) {
  try {
    const u = new URL(url);
    if (!u.hostname.endsWith('zakupki.gov.ru')) return '';
    if (/common-info\.html$/.test(u.pathname)) return u.href.replace('common-info.html', 'documents.html');
    return '';
  } catch (_) {return '';}
}
async function discover(id) {
  return await inject(id, 'document_collector.js', '__tnDiscoverDocuments') ||
    {direct_links:[], docs_tab:'', page:''};
}
function safeFilename(input, fallback) {
  const name=String(input||'').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').replace(/\.+$/,'').trim();
  if(name.length<=110)return name||fallback;
  const suffix=(name.match(/\.(pdf|docx|xlsx|xlsm|txt|md|csv|xml|doc|xls|rtf|rar|7z|zip)$/i)||[''])[0];
  return name.slice(0,110-suffix.length)+suffix;
}
async function singleDownload(url, i, number, workId, title, claimToken) {
  const source=new URL(url);
  if(source.protocol!=='https:' || source.hostname!=='zakupki.gov.ru') throw new Error('Допустимы только документы ЕИС по HTTPS');
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),90000);
  try {
    const response=await fetch(url,{credentials:'include',signal:controller.signal});
    if(!response.ok)throw new Error('ЕИС: HTTP '+response.status);
    if(new URL(response.url).hostname!=='zakupki.gov.ru')throw new Error('Документ перенаправлен за пределы ЕИС');
    const mime=(response.headers.get('content-type')||'').split(';')[0].trim();
    if(/html|javascript|^image\//i.test(mime))throw new Error('ЕИС вернула страницу вместо документа');
    const limit=30*1024*1024;
    if(Number(response.headers.get('content-length'))>limit)throw new Error('Документ больше 30 МБ');
    const reader=response.body.getReader(),parts=[];let size=0;
    while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>limit){await reader.cancel();throw new Error('Документ больше 30 МБ');}parts.push(value);}
    if(!size)throw new Error('Пустой файл ЕИС');
    const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
    const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');
    let disposition=response.headers.get('content-disposition')||'';
    let found=disposition.match(/filename\*\s*=\s*UTF-8''([^;]+)/i), name='';
    if(found)try{name=decodeURIComponent(found[1].replace(/^"|"$/g,''));}catch(_){}
    if(!name){found=disposition.match(/filename\s*=\s*"?([^";]+)/i);name=found?.[1]||'';}
    if(!name)name=decodeURIComponent(new URL(response.url).pathname.split('/').pop()||'') || title || ('Документ_'+i);
    name=safeFilename(name,'Документ_'+i);
    if(!/\.(pdf|docx|xlsx|xlsm|txt|md|csv|xml|doc|xls|rtf|rar|7z|zip)$/i.test(name)){
      let suffix=({'application/pdf':'.pdf','text/plain':'.txt','application/xml':'.xml','text/xml':'.xml','application/zip':'.zip','application/vnd.openxmlformats-officedocument.wordprocessingml.document':'.docx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'.xlsx'})[mime];
      if(!suffix && new TextDecoder().decode(bytes.slice(0,5))==='%PDF-')suffix='.pdf';
      if(!suffix)throw new Error('Не удалось определить формат документа');name+=suffix;
    }
    let binary='';for(let k=0;k<bytes.length;k+=32768)binary+=String.fromCharCode(...bytes.subarray(k,k+32768));
    const requestId='import-'+(++claimSequence);
    const result=await new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{pendingImports.delete(requestId);reject(new Error('QX не подтвердил сохранение документа'));},60000);
      pendingImports.set(requestId, value=>{clearTimeout(timeout);resolve(value);});
      send({type:'file_upload',id:activeJobId,request_id:requestId,url,claim_token:claimToken,filename:name,data:btoa(binary),sha256:digest});
    });
    if(!result.ok)throw new Error(result.error||'QX отклонил документ');
    return {file:name,url,sha256:digest};
  }finally{clearTimeout(timer);}
}

async function collectEmbeddedEis(tabId, progress) {
  progress('Считываю таблицу КТРУ и прокручиваю характеристики в ЕИС…');
  await bounded(chrome.scripting.executeScript({target:{tabId}, files:['eis_characteristics.js']}),
    12000, 'подключения таблицы ЕИС');
  const r = await bounded(chrome.scripting.executeScript({
    target:{tabId},
    func: async () => typeof window.__tnCollectEisEmbeddedSpec === 'function'
      ? await window.__tnCollectEisEmbeddedSpec() : null
  }), 30000, 'чтения встроенного ООЗ ЕИС');
  return r?.[0]?.result || null;
}

function isMatchingEisNotice(url, number) {
  try {
    const u=new URL(url);
    if (!/(^|\.)zakupki\.gov\.ru$/i.test(u.hostname)) return false;
    const reg=u.searchParams.get('regNumber');
    return !!reg && reg===number && /^https:$/.test(u.protocol);
  } catch (_) {return false;}
}
async function waitNewTab(tabId, target, progress=()=>{}) {
  // tabs.create уже открывает отдельную страницу. Обработка остаётся в ней.
  await navigate(tabId, target, progress);
}
async function documentWorkflow(cmd, progress) {
  const current = await activeTab();
  let number = String(cmd.number || '').trim();
  if (!number) {const snapshot=await captureActiveTab();number=String(snapshot.number || '').trim();}
  if (number && !/^[A-Za-zА-Яа-яЁё0-9._-]{5,60}$/.test(number))
    throw new Error('Некорректный номер закупки');

  // Всегда оставляем исходную карточку СБИС/ЕИС нетронутой.
  // В браузере открывается новая рабочая вкладка, и все переходы идут ТОЛЬКО в ней.
  const provided = String(cmd.url || '');
  let target = '';
  if (isMatchingEisNotice(provided,number)) target=provided;
  else if (isMatchingEisNotice(current.url || '',number)) target=current.url;
  else {
    try {
      const originalLinks=await discover(current.id);
      if (isMatchingEisNotice(originalLinks.eis_link || '', number)) target=originalLinks.eis_link;
    } catch (_) {/* На не-ЕИС странице мог быть закрыт доступ к DOM */}
  }
  if (!target) target=expectedEisURL(number);
  // Коммерческие закупки не всегда имеют извещение в ЕИС.
  if (!target) {
    if (provided && /^https:\/\//i.test(provided) && provided.includes(number)) target=provided;
    else if (String(current.url||'').includes(number)) target=current.url;
    else throw new Error('Не обнаружена ссылка на нужную закупку. Для коммерческой закупки откройте её карточку вручную.');
  }
  progress('Открываю закупку в ОТДЕЛЬНОЙ вкладке (исходная вкладка не изменяется)…');
  diagnostic(cmd.id, 'navigation.target', {destination_host:new URL(target).hostname,
    destination_page:new URL(target).pathname.slice(0,95), number_present:!!number});
  const workTab=await chrome.tabs.create({url:target,active:true,index:current.index+1});
  if (!workTab?.id) throw new Error('Браузер не открыл новую вкладку.');
  const tabId=workTab.id;
  await waitNewTab(tabId,target,progress);
  let url=target;
  try { const snapshot=await inject(tabId,'extractor.js','__tendernotesExtractPage');send({type:'snapshot',id:cmd.id,data:snapshot}); } catch(e) { diagnostic(cmd.id,'metadata.error',{error_message:String(e?.message||e)}); }
  progress('Ищу раздел «Документы»…');
  let found = await discover(tabId);
  diagnostic(cmd.id, 'documents.discovery_initial', {links:(found.direct_links||[]).length,
    has_eis_link:!!found.eis_link, has_docs_tab:!!found.docs_tab, scope_ok:found.scope_ok!==false});
  if (!new URL(found.page || url).hostname.endsWith('zakupki.gov.ru') &&
      isMatchingEisNotice(found.eis_link || '',number)) {
    // Переходим на официальный источник ТОЛЬКО в открытой рабочей вкладке.
    const official=found.eis_link;
    progress('Перехожу в ЕИС в новой вкладке…');
    await navigate(tabId,official,progress);
    url=official;
    found=await discover(tabId);
  }
  // ВАЖНО: в ЕИС основное структурированное ООЗ часто размещено на вкладке
  // «Общая информация», а вовсе не в загруженных файлах. Читаем ДО ухода
  // на «Документы» и сохраняем даже при недоступности файлов.
  let eis = null;
  const embeddedErrors = [];
  try {
    const here = new URL(found.page || url);
    if (here.hostname.endsWith('zakupki.gov.ru')) {
      if (/documents\.html$/.test(here.pathname)) {
        const common = here.href.replace('documents.html','common-info.html');
        await navigate(tabId, common,progress);
        url = common;
        found = await discover(tabId);
      }
      diagnostic(cmd.id, 'eis.capture_start', {page:here.pathname.slice(0,90)});
      eis = await collectEmbeddedEis(tabId, progress);
      diagnostic(cmd.id, 'eis.capture_result', {found_section:!!eis?.found_section,
        found_table:!!eis?.found_table, expanded:eis?.expanded || 0,
        position_count:(eis?.positions||[]).length, row_count:(eis?.rows||[]).length,
        scroll_steps:eis?.scroll_steps||0, complete:!!eis?.completed,
        auxiliary_nodes_removed:eis?.diagnostics?.auxiliary_position_nodes_removed||0,
        warnings_count:(eis?.warnings||[]).length});
      if(eis?.diagnostics) diagnostic(cmd.id, 'eis.dom_structure', eis.diagnostics);
      if (eis?.positions?.length) for(const pos of eis.positions.slice(0,20)) {
        diagnostic(cmd.id, 'eis.position_summary', {
          position_index:pos.index || 0,
          has_quantity:!!pos.quantity, has_unit_price:!!pos.unit_price,
          rows_assigned:(eis.rows||[]).filter(r=>r.position_id===pos.id).length,
          has_code:!!pos.code,
        });
      }
      if (eis?.warnings?.length) embeddedErrors.push(...eis.warnings.map(x=>'ЕИС: '+x));
      progress(`ЕИС: считано ${eis?.rows?.length || 0} характеристик.`);
    }
  } catch (error) {
    diagnostic(cmd.id, 'eis.capture_error', {error_name:error?.name||'Error',
      error_message:String(error?.message||error).slice(0,150)});
    embeddedErrors.push('Не удалось считать встроенное ООЗ ЕИС: ' + String(error?.message||error));
  }
  let destination = found.docs_tab || fallbackEisDocuments(url);
  if (destination && destination !== found.page) {
    progress('Перехожу на вкладку «Документы»…');
    try {
      await navigate(tabId, destination, progress);
      found = await discover(tabId);
    } catch (e) {
      // Do not discard successful EIS capture when the documents tab is slow
      // or the user closes the working tab. The returned result stays partial.
      const description=String(e?.message||e);
      diagnostic(cmd.id, 'documents.navigation_failed', {error_message:description.slice(0,155), eis_saved:!!eis});
      embeddedErrors.push('Вкладка документов недоступна: '+description+'; данные ЕИС сохранены.');
      found={...found, direct_links:[], page:url, warnings:[]};
    }
  } else if (!destination) {
    // Часто на СБИС вкладка реализована JS-кнопкой.
    await chrome.scripting.executeScript({target:{tabId}, files:['document_collector.js']});
    const click = await chrome.scripting.executeScript({target:{tabId}, func:() =>
      window.__tnClickDocumentsTab && window.__tnClickDocumentsTab()});
    if (click?.[0]?.result) {await wait(1700); found=await discover(tabId);}
  }
  let links = found.direct_links || [];
  // Площадки с динамической загрузкой могут показать документы позже.
  if (!links.length) {
    for (let attempt=0; attempt<4 && !links.length; attempt++) {
      await wait(1100+attempt*650);
      try {found=await discover(tabId);links=found.direct_links || [];}
      catch(e) {embeddedErrors.push('Поиск вложений: '+String(e?.message||e));break;}
    }
  }
  const downloaded = [], errors=[...embeddedErrors, ...(found.warnings||[])];
  diagnostic(cmd.id, 'documents.links', {found_count:links.length,
    scope_ok:found.scope_ok!==false, current_revision_only:!!found.current_revision_only,
    auxiliary_skipped:found.auxiliary_skipped||0});
  if (found.scope_ok === false) links = [];
  const limit = Math.min(links.length, 100);
  const safeSkipped = Array.isArray(cmd.skip_urls) ? cmd.skip_urls.slice(0,100)
    .filter(url => typeof url==='string' && url.length<2000) : [];
  const skipUrls = new Set(safeSkipped);
  const skippedUrls = [];
  const workId = String(Date.now());
  for (let i=0; i<limit; i++) {
    if (typeof cancelledJobs !== 'undefined' && cancelledJobs.has(cmd.id)) throw new Error('Загрузка отменена пользователем после безопасного завершения предыдущего файла');
    progress(`Скачиваю документы: ${i+1} из ${limit}`);
    const entry = links[i];
    if (skipUrls.has(entry.url)) {
      skippedUrls.push(entry.url);
      continue;
    }
    let decision;
    try {decision=await requestClaim(cmd.id,entry.url);}
    catch(e) {errors.push('QX: документ не зарезервирован; '+String(e?.message||e));continue;}
    if (decision?.action==='skip') {skippedUrls.push(entry.url);continue;}
    if (decision?.action!=='download' || !/^[a-f0-9]{40}$/.test(String(decision?.claim_token||''))) {
      errors.push('Документ занят другим обработчиком QX; повторите позже');continue;
    }
    const claimToken=decision.claim_token;
    send({type:'file_progress', id:cmd.id, file:{source_url:entry.url, title:entry.title||'', state:'downloading', claim_token:claimToken}});
    try {
      const file=await singleDownload(entry.url, i+1, number, workId, entry.title, claimToken);
      downloaded.push(file);
      send({type:'file_progress', id:cmd.id, file:{source_url:entry.url, title:entry.title||'', state:'downloaded', file:file.file, claim_token:claimToken}});
      diagnostic(cmd.id, 'documents.file_downloaded', {index:i+1});
    } catch (e) {
      diagnostic(cmd.id, 'documents.file_error', {index:i+1, error_name:e?.name||'Error',
        error_message:String(e?.message||e).slice(0,140)});
      errors.push((entry.title || `Документ ${i+1}`) + ': ' + String(e?.message || e));
      send({type:'file_progress', id:cmd.id, file:{source_url:entry.url, title:entry.title||'', state:'error', error:String(e?.message || e).slice(0,300), claim_token:claimToken}});
    }
  }
  if (typeof cancelledJobs !== 'undefined' && cancelledJobs.has(cmd.id)) throw new Error('Загрузка отменена пользователем');
  if (links.length > limit) errors.push(`Найдено ${links.length} ссылок; для безопасности первые ${limit} обработаны.`);
  if (!links.length) errors.push('Вложения не получены автоматически. Таблица ЕИС, если считана, сохранена. Для полного анализа могут понадобиться файлы, загруженные вручную.');
  diagnostic(cmd.id, 'documents.finished', {requested:limit, downloaded:downloaded.length,
    errors_count:errors.length});
  progress('Загрузка завершена.');
  return {number, documents_page:found.page, count_found:links.length,
          restricted_to_current_notice:!!found.current_revision_only,
          downloaded, skipped_urls:skippedUrls, errors, eis, bulk_available:!!found.bulk_button_available,
          source_tab_untouched:true, opened_new_tab:true, source_page:current.url,
          working_tab_url:(await chrome.tabs.get(tabId).catch(()=>null))?.url || url};
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(msg?.type!=='qx-pair' || !/^http:\/\/127\.0\.0\.1:18764\/extension-pair(?:[?#]|$)/.test(sender.url||'') || !/^[A-Za-z0-9_-]{32,100}$/.test(msg.token||''))return;
  chrome.storage.local.set({qx_token:msg.token}).then(()=>{if(socket)socket.close();socket=null;paired=false;connect();reply({ok:true});});return true;
});
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);
chrome.alarms.create('reconnect', {periodInMinutes: 0.5});
chrome.alarms.onAlarm.addListener(a => {if (a.name === 'reconnect') connect();});
chrome.action.onClicked.addListener(() => connect());
connect();
