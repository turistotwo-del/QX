/* TenderNotes v5.18: считывание структурированного ООЗ/КТРУ из ЕИС.
 * Выполняется только после нажатия пользователем «Док.+ТЗ»/«ТЗ».
 * Значения не интерпретируются и не подменяются. Не обращается к внешним API.
 */
window.__tnCollectEisEmbeddedSpec = async function () {
  'use strict';
  const page = location.href;
  const number = new URL(page).searchParams.get('regNumber') || '';
  const result = {url: page, number, source: 'ЕИС — информация об объекте закупки',
    rows: [], positions: [], found_section: false, found_table: false,
    expanded: 0, scroll_steps: 0, completed: false, warnings: [], diagnostics: {parser_version:'1.15.0'}};
  if (!/(^|\.)zakupki\.gov\.ru$/i.test(location.hostname)) {
    result.warnings.push('Встроенная таблица считывается только с карточки ЕИС.');
    return result;
  }
  const normal = v => String(v || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const lower = v => normal(v).toLocaleLowerCase('ru-RU');
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  const isVisible = el => !!(el && el.isConnected && el.getClientRects().length &&
    getComputedStyle(el).visibility !== 'hidden');
  const codeRX = /\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8,10}\b/g;
  const nameHeadRX = /наименование\s+характеристики/i;
  const headersRX = [nameHeadRX, /значение\s+характеристики/i,
    /единица\s+измерения/i, /инструкц(?:ия|ии)\s+по\s+заполнению/i];
  const shortText = el => normal((el && (el.innerText || el.textContent)) || '');
  const findSection = () => {
    const nodes = document.querySelectorAll('h1,h2,h3,h4,h5,h6,[class*="title"],[class*="Title"]');
    for (const n of nodes) {
      if (isVisible(n) && /^информация\s+об\s+объекте\s+закупки$/i.test(shortText(n))) return n;
    }
    return null;
  };
  const heading = findSection();
  // Metadata only. Never send the actual tender specification as a debug log.
  result.diagnostics.heading_count=document.querySelectorAll('h1,h2,h3,h4,h5,h6').length;
  result.diagnostics.visible_table_count=[...document.querySelectorAll('table')].filter(isVisible).length;
  result.diagnostics.visible_row_count=[...document.querySelectorAll('tr,[role="row"]')].filter(isVisible).length;
  result.diagnostics.header_name_candidates=[...document.querySelectorAll('th,td,span,div,p,label')]
    .filter(el=>isVisible(el) && shortText(el).length<85 && nameHeadRX.test(shortText(el))).length;
  result.diagnostics.code_candidate_count=[...document.querySelectorAll('a,span,[class*="code"],[class*="Code"]')]
    .filter(el=>isVisible(el) && shortText(el).length<=125 && /\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8,10}\b/.test(shortText(el))).length;
  result.diagnostics.document_ready_state=document.readyState;
  if (!heading) {
    result.warnings.push('Раздел «Информация об объекте закупки» не найден на этой странице.');
    return result;
  }
  result.found_section = true;
  // После раскрытия КТРУ DOM может полностью перестраиваться: ищем актуальные узлы.
  const tableMarkers = () => {
    const matches = [];
    for (const el of document.querySelectorAll('th,td,span,div,p,label')) {
      if (!isVisible(el)) continue;
      const content = shortText(el);
      if (content.length > 85 || !nameHeadRX.test(content)) continue;
      // Ищем кратчайший контейнер, содержащий все четыре заголовка.
      let ancestor = el.parentElement;
      for (let i=0; ancestor && i<7; i++, ancestor=ancestor.parentElement) {
        const t = shortText(ancestor);
        if (t.length > 8000) break;
        if (headersRX.every(rx => rx.test(t))) {
          matches.push(ancestor);
          break;
        }
      }
    }
    return [...new Set(matches)];
  };
  // Каждая физическая строка объекта закупки является отдельной позицией.
  // КОД КТРУ НЕ уникален: две строки «Системный блок» могут иметь одинаковый код,
  // но разные требования. Не используем Map<code, position>.
  const codeSingleRX = /\b\d{2}\.\d{2}\.\d{2}\.\d{3}-\d{8,10}\b/;
  const itemNameRX = /системн(?:ый|ые)\s+блок|моноблок|ноутбук|сервер|рабоч(?:ая|ие)\s+станци|монитор|клавиатур|мышь|мфу|принтер|сканер|компьютер|источник бесперебойн|периферийн|оборудовани/i;
  const getDirectCells = row => {
    if (!row) return [];
    const cols = [...row.children].filter(el=>el.matches('td,th,[role="cell"],[role="gridcell"]'));
    if(cols.length) return cols.map(shortText);
    // Современная DIV-верстка ЕИС имеет отдельные ячейки без тегов <td>.
    const child=[...row.children].filter(isVisible);
    if(row.matches('div,[role="row"]') && child.length>=4 && child.length<=9)
      return child.map(shortText);
    return [];
  };
  const nameFromRow = (row, code) => {
    const cells=getDirectCells(row);
    const nameCell=cells.find(c=>itemNameRX.test(c) && !/^(?:наименование|информация об объекте)/i.test(c));
    const t=normal(nameCell || shortText(row).replace(code,''));
    const product=(t.match(/системн(?:ый|ые)\s+блок|монитор,?\s*подключаемый\s+к\s+компьютеру|монитор|моноблок|клавиатура|мышь\s+компьютерная|мышь|ноутбук|сервер|мфу|принтер|сканер|компьютер/i)||[])[0];
    if(!product)return '';
    const after=t.slice(t.toLocaleLowerCase('ru-RU').indexOf(product.toLocaleLowerCase('ru-RU'))+product.length);
    const variant=after.match(/^\s*(?:[–—-]\s*)?(тип\s*№?\s*[\w-]{1,12})\b/i);
    return normal(product+(variant?' '+variant[1]:''));
  };
  const parseValues = row => {
    const cells=getDirectCells(row);
    // Таблица ЕИС: код, наименование, единица, количество, цена, стоимость.
    // Извлекаем количество только из отдельной ячейки, а не из 32 ГБ ОЗУ.
    const money = s => normal(s).replace(/[₽\s\u00a0]/g,'');
    const num = s => /^\d{1,8}(?:[ ,.]\d{1,3})?$/.test(normal(s));
    let unit='', quantity='', unit_price='', total_price='';
    if (cells.length >= 4) {
      const pos=cells.findIndex(c=>itemNameRX.test(c));
      if(pos>=0) {
        const following=cells.slice(pos+1);
        if(following.length && /^(?:шт(?:ук[аи])?|единиц[аы]?|компл(?:ект)?)$/i.test(normal(following[0]))) {
          unit=normal(following[0]);following.shift();
        }
        if(following.length && num(following[0])) {quantity=normal(following[0]); following.shift();}
        if(following.length && /^\d[\d ,.]*(?:₽)?$/.test(following[0])) {unit_price=money(following[0]); following.shift();}
        if(following.length && /^\d[\d ,.]*(?:₽)?$/.test(following[0])) {total_price=money(following[0]);}
      }
    }
    return {quantity,unit,unit_price,total_price};
  };
  const findPositionNodes = () => {
    const found=[];
    const seen=new Set();
    // Первая очередь: строки закупки (таблицы ЕИС), без дедупликации по КТРУ.
    for(const row of document.querySelectorAll('tr,[role="row"]')) {
      if(!isVisible(row))continue;
      const raw=shortText(row);
      if(raw.length>2100 || !codeSingleRX.test(raw) || !itemNameRX.test(raw))continue;
      if(headersRX[0].test(raw))continue;
      const nested=[...row.querySelectorAll('tr,[role="row"]')].some(c=>c!==row && codeSingleRX.test(shortText(c)));
      if(nested)continue;
      found.push(row);seen.add(row);
    }
    // DIV-верстка. Якорь КТРУ уникален для физической строки даже при повторе кода.
    for(const link of document.querySelectorAll('a,span,[class*="code"],[class*="Code"]')) {
      if(!isVisible(link))continue;
      const own=shortText(link);
      if(own.length>125 || !codeSingleRX.test(own))continue;
      let row=link.closest('tr,[role="row"]');
      if(!row) {
        let curr=link;
        for(let n=0;curr.parentElement && n<8;n++) {
          const up=curr.parentElement,t=shortText(up);
          if(t.length>2100 || (t.match(codeRX)||[]).length>1)break;
          curr=up;
          if(itemNameRX.test(t) && up.children.length>=2)break;
        }
        row=curr;
      }
      if(!row || seen.has(row) || !isVisible(row))continue;
      const t=shortText(row);
      if(!itemNameRX.test(t) || t.length>2100)continue;
      if(found.some(old=>old===row || old.contains(row) || row.contains(old)))continue;
      found.push(row);seen.add(row);
    }
    found.sort((a,b)=>a===b?0:
      a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
    // ЕИС повторяет КТРУ в таблице национального режима. Такое упоминание
    // без количества и цены НЕ является дополнительной товарной позицией.
    // Не объединяем настоящие повторяющиеся товары по коду КТРУ: если у
    // каждого товара отдельная количественная строка, оставляем ОБА.
    const candidates=found.map(node=>({node,
      text:shortText(node), code:(shortText(node).match(codeSingleRX)||[''])[0],
      meta:parseValues(node)}));
    const quantitativeCodes=new Set(candidates.filter(x=>x.meta.quantity || x.meta.unit_price || x.meta.total_price).map(x=>x.code));
    const regimeRX=/ограничени[ея]\s+закупок|запрет\s+закупок|национальн(?:ый|ого|ому)\s+режим|происхождени[ея]\s+товар|иностранн(?:ых|ого|ых\s+государств)|преимуществ[ао]\s+при\s+закупк/i;
    const truePositions=candidates.filter(x=>!(!x.meta.quantity && !x.meta.unit_price && !x.meta.total_price &&
      quantitativeCodes.has(x.code) && regimeRX.test(x.text)));
    // Count only, no tender contents in diagnostic logs.
    result.diagnostics.auxiliary_position_nodes_removed=candidates.length-truePositions.length;
    return truePositions.map(x=>x.node).slice(0,100);
  };
  const initialPositionNodes=findPositionNodes();
  result.diagnostics.detected_position_nodes=initialPositionNodes.length;
  result.diagnostics.markers_before_expand=tableMarkers().length;
  result.positions=initialPositionNodes.map((node,i)=>{
    const code=(shortText(node).match(codeSingleRX)||[''])[0];
    const meta=parseValues(node);
    return {id:`pos-${i+1}`, index:i+1, code, name:nameFromRow(node,code)||'Позиция без распознанного названия',
      description:shortText(node).slice(0,550), ...meta};
  });
  if(!result.positions.length) result.warnings.push('Строки товарных позиций не определены — разделение ТЗ по позициям может быть неполным.');
  // Не нажимаем ссылки и кнопки отправки заявки. Ищем только стрелку
  // раскрытия строки КТРУ. У ЕИС она может быть SVG без подписи.
  const expandControls = row => {
    const selectors=[
      '[aria-expanded="false"]','[data-toggle="collapse"]','[data-bs-toggle="collapse"]',
      'button[aria-label*="Развер"]','button[aria-label*="раскр"]',
      '[class*="expand"]','[class*="Expand"]','[class*="chevron"]',
      '[class*="Chevron"]','[class*="collapse"]','[class*="toggle"]',
      '[class*="arrow"]','[class*="Arrow"]'
    ];
    const result=[];
    for(const sel of selectors) for(const el of row.querySelectorAll(sel)) {
      const target=el.closest('button,[role="button"]') || el;
      if(!result.includes(target))result.push(target);
    }
    const firstCell=row.querySelector('td:first-child,[role="cell"]:first-child');
    if(firstCell) {
      const icon=firstCell.querySelector('svg,path,i,[class*="icon"],button,[role="button"]');
      if(icon)result.push(icon.closest('button,[role="button"]') || icon.parentElement || firstCell);
      else if(firstCell.querySelector('span'))result.push(firstCell);
    }
    return result.filter(x=>x && isVisible(x) && !x.closest('a[href]'));
  };
  const nodes=initialPositionNodes;
  if(!tableMarkers().length || result.positions.length>1) {
    for(let i=0;i<nodes.length;i++) {
      // При перерисовке ищем строку по порядковому номеру, а не по коду КТРУ.
      const fresh=findPositionNodes()[i] || nodes[i];
      const before=tableMarkers().length;
      for(const target of expandControls(fresh)) {
        const label=lower(target.getAttribute('aria-label') || target.getAttribute('title') || target.innerText);
        if(target.getAttribute('aria-expanded')==='true' || target.closest('[aria-expanded="true"]'))continue;
        if(/скачать|подать|заказат|подписат|отмен|удал|закрыть/.test(label))continue;
        try {
          target.click();result.expanded++;await pause(420);
          if(tableMarkers().length>before)break;
        }catch(_){}
      }
    }
  }
  result.diagnostics.markers_after_expand=tableMarkers().length;
  result.diagnostics.expanded_controls=result.expanded;
  // Если невозможно надёжно раскрыть позицию, не объявляем успех.
  if (!tableMarkers().length) {
    result.warnings.push('Таблица характеристик не раскрыта автоматически. Откройте стрелку слева от КТРУ и повторите «Док.+ТЗ».');
    return result;
  }
  result.found_table = true;
  const rowsMap = new Map();
  const validName = s => s.length >= 4 && s.length <= 360 &&
    !headersRX.some(rx => rx.test(s)) && !/^(?:итого|количество|наименование\s+товара)$/.test(lower(s));
  function add(values, context) {
    if (!values || !values.length) return;
    // EIS may render a continuation such as Wi-Fi or Display Port in one
    // colspan cell rather than four empty/filled columns. Keep its context.
    if (values.length === 1) values=[values[0], '', '', ''];
    const vals = values.slice(0,4).map(v=>normal(v).slice(0,1300));
    const [name, value, unit='', instruction=''] = vals;
    // Многострочные наборы значений ЕИС: имя характеристики находится только
    // в первой строке, следующие строки содержат самостоятельные значения
    // в ПЕРВОЙ колонке. Не считаем их отдельными характеристиками.
    // Работает и для фиксированных списков «Отсутствует беспроводная связь»
    // (3G, 4G, 5G, NFC, Wi-Fi, Bluetooth), и для видеовыходов HDMI/Display Port.
    const isWireless=/^(?:3G\s*\(UMTS\)|4G\s*\(LTE\)|5G|NFC|Wi[- ]Fi|Bluetooth)$/i.test(name);
    const isVideo=/^(?:HDMI|Display\s*Port|DisplayPort|VGA|DVI)$/i.test(name);
    const isUsb=/^(?:USB Type-C|USB)$/i.test(name);
    if (!value && (isWireless || isVideo || isUsb)) {
      const entries=[...rowsMap.values()];
      const samePosition=entries.filter(r=>r.position_id===(context.position_id||''));
      const targetName=isWireless ? /(?:беспроводная связь|беспроводн\w* интерфейс)/i :
        isVideo ? /(?:видеовыход|видео\s*разъ[её]м|тип.*видеовыхода)/i :
        /(?:тип.*интерфейс|интерфейс)/i;
      const canAppend=r=>r && !r.value.split(/\s*;\s*/).some(v=>lower(v)===lower(name));
      // Выбор «все значения», фиксированная многозначная строка или
      // последняя тематически подходящая строка после виртуализации таблицы.
      const candidates=samePosition.filter(r=>targetName.test(r.name) && canAppend(r) &&
        (/все значения характеристики/i.test(r.instruction) ||
         /значение характеристики не может изменяться/i.test(r.instruction)));
      const last=entries.length ? entries[entries.length-1] : null;
      const destination=candidates.length===1?candidates[0]:
        (last && last.position_id===(context.position_id||'') &&
         targetName.test(last.name) && canAppend(last) &&
         /(?:все значения характеристики|значение характеристики не может изменяться)/i.test(last.instruction)
         ? last : null);
      if(destination) destination.value+='; '+name;
      else {
        // A scroll scan sees the same physical continuation many times.
        // Already appended values must not create spurious warnings.
        const alreadyIncluded=samePosition.some(r=>targetName.test(r.name) &&
          r.value.split(/\s*;\s*/).some(v=>lower(v)===lower(name)));
        if(!alreadyIncluded && !result.warnings.includes('Продолжение значения ЕИС без однозначной позиции: '+name))
          result.warnings.push('Продолжение значения ЕИС без однозначной позиции: '+name);
      }
      return;
    }
    if (!validName(name) || !value || value.length > 260 || name === value) return;
    // Категориальные требования тоже полноценные значения: IPS, DVD-RW,
    // «Внешний», «Интегрированная», интерфейс или тип устройства.
    // Доверяем корректно распознанной 4-колоночной строке ЕИС только при
    // явной инструкции заполнения, единице или проверяемом значении.
    const officialInstruction = /(?:участник.{0,80}заявк|значение.{0,80}не может изменяться)/i.test(instruction);
    const knownValue = /[<>≤≥=\d]|\b(?:да|нет|имеется|отсутствует|DDR\d|NVMe|SSD|USB|HDMI|DisplayPort|Bluetooth|Wi-Fi|IPS|DVD-RW|Внешний|Встроенный|Интегрированн\w*)\b/i.test(value);
    if (!officialInstruction && !knownValue && !unit) return;
    const key = vals.map(x=>lower(x)).join('\u001f') + '|' + (context.position_id || 'unassigned');
    if (rowsMap.has(key)) return;
    if (rowsMap.size >= 800) return;
    rowsMap.set(key, {name, value, unit, instruction,
      position_id: context.position_id || '', position_index: context.position_index || 0,
      position_code: context.position_code || '', equipment: context.equipment || ''});
  }
  const findContext = (marker, fresh) => {
    // Последняя предшествующая строка товара. В ЕИС характеристики
    // развёрнутой строки располагаются после самой строки в DOM.
    let index=-1;
    for(let i=0;i<fresh.length;i++) {
      if(fresh[i]===marker || fresh[i].contains(marker) ||
         !!(fresh[i].compareDocumentPosition(marker)&Node.DOCUMENT_POSITION_FOLLOWING)) index=i;
    }
    const p = index>=0 ? result.positions[index] : null;
    if(!p) return {position_id:'',position_index:0,position_code:'',equipment:''};
    return {position_id:p.id,position_index:p.index,position_code:p.code,equipment:p.name};
  };
  const rowCells = el => {
    if (el.matches('tr')) return [...el.children].filter(x=>/^(TD|TH)$/.test(x.tagName)).map(shortText);
    if (el.getAttribute('role') === 'row') {
      const cells = [...el.children].filter(x=>x.getAttribute('role') === 'cell' || x.getAttribute('role') === 'gridcell');
      if (cells.length >= 2) return cells.map(shortText);
    }
    const children = [...el.children].filter(isVisible);
    if (children.length < 4 || children.length > 6) return [];
    const coords = children.map(x=>x.getBoundingClientRect());
    if (coords.some(r=>!r.width)) return [];
    // Требуется четыре отдельно расположенные колонки, как в ЕИС.
    if (!(coords[0].left + 35 < coords[1].left && coords[1].left + 30 < coords[2].left &&
          coords[2].left + 30 < coords[3].left)) return [];
    if (Math.max(...coords.map(r=>r.top))-Math.min(...coords.map(r=>r.top)) > 55) return [];
    return children.map(shortText);
  };
  function collectNow() {
    const markers = tableMarkers();
    // Reuse one position snapshot per scroll step. Calling findPositionNodes
    // inside each marker (and scanning all DOM rows repeatedly) was costly.
    const fresh = findPositionNodes();
    for (const marker of markers) {
      const ctx = findContext(marker, fresh);
      let area = marker.closest('table,[role="table"],[class*="characteristic"],[class*="Characteristic"]') || marker;
      if(area===marker) {
        // Таблица DIV: заголовок и скроллируемые строки находятся в одном
        // ближайшем контейнере. Не поднимаемся до всего раздела закупки.
        for(let i=0;i<6 && area.parentElement && area.parentElement!==document.body;i++) {
          const upper=area.parentElement;
          if(shortText(upper).length>48000)break;
          if(markers.filter(x=>upper.contains(x)).length>1)break;
          area=upper;
          if(area.querySelectorAll('tr,[role="row"]').length>1 ||
             area.querySelectorAll('[class*="row"],[class*="Row"]').length>3)break;
        }
      }
      const trRows = area.querySelectorAll('tr,[role="row"]');
      if (trRows.length) {
        for (const tr of trRows) if (isVisible(tr)) add(rowCells(tr),ctx);
      }
      // Дивовая таблица без tr: DOM-сетка из четырёх колонок.
      // Скан ограничен разделом характеристик.
      const divs = area.querySelectorAll('div,[class*="row"],[class*="Row"]');
      for (const el of divs) {
        if (!isVisible(el)) continue;
        add(rowCells(el),ctx);
      }
    }
  }
  const findScrollTargets = () => {
    const found = new Set();
    for (const marker of tableMarkers()) {
      let p = marker;
      for (let i=0;p && i<8;i++,p=p.parentElement) {
        if (!isVisible(p)) continue;
        if (p.clientHeight > 60 && p.scrollHeight > p.clientHeight+30 &&
            p.clientHeight < window.innerHeight*1.5) found.add(p);
      }
      // В некоторых версиях ЕИС заголовки — снаружи прокручиваемой области.
      const scope = marker.parentElement?.parentElement?.parentElement || marker;
      for (const el of scope.querySelectorAll('*')) {
        if (el.clientHeight > 60 && el.scrollHeight > el.clientHeight + 30 &&
            el.clientHeight < window.innerHeight*1.5) found.add(el);
      }
    }
    // Предпочесть вложенный скролл таблицы вместо всей страницы.
    return [...found].filter(el=>el!==document.body && el!==document.documentElement)
      .sort((a,b)=>a.scrollHeight-b.scrollHeight).slice(0,12);
  };
  collectNow();
  const targets = findScrollTargets();
  result.diagnostics.scroll_containers=targets.length;
  let truncation = false;
  for(const scroller of targets) {
    if(!scroller.isConnected) continue;
    const previousTop = scroller.scrollTop;
    try {
      scroller.scrollTop = 0;
      await pause(150);
      collectNow();
      let n=0, stagnant=0;
      const step = Math.max(60,Math.round(scroller.clientHeight*0.78));
      while(n++<220 && result.scroll_steps<500) {
        const before = scroller.scrollTop;
        const countBefore = rowsMap.size;
        scroller.scrollTop = Math.min(scroller.scrollHeight, before + step);
        await pause(140);
        result.scroll_steps++;
        collectNow();
        if (scroller.scrollTop <= before+1) break;
        if (rowsMap.size === countBefore) stagnant++; else stagnant=0;
        if(stagnant >= 65) {
          if (scroller.scrollTop + scroller.clientHeight < scroller.scrollHeight-4) truncation=true;
          break;
        }
      }
      if((n>=220 || result.scroll_steps>=500) && scroller.scrollTop + scroller.clientHeight < scroller.scrollHeight-4) truncation=true;
      if (scroller.scrollTop + scroller.clientHeight < scroller.scrollHeight-4) truncation=true;
    } finally {scroller.scrollTop = previousTop;}
  }
  result.rows = [...rowsMap.values()];
  result.diagnostics.extracted_rows=result.rows.length;
  result.diagnostics.scroll_actions=result.scroll_steps;
  if (rowsMap.size >= 800) {truncation=true;result.warnings.push('Ограничение 800 строк. Возможно, извлечены не все характеристики.');}
  if (!result.rows.length) result.warnings.push('Заголовки таблицы найдены, но структурированные строки не удалось прочитать. Проверьте раскрытие позиции и загрузку страницы.');
  if (truncation) result.warnings.push('Не удалось подтвердить чтение всей прокручиваемой таблицы. Проверьте нижние строки вручную.');
  if (result.positions.length>1) {
    const covered=new Set(result.rows.map(r=>r.position_id).filter(Boolean));
    const missing=result.positions.filter(p=>!covered.has(p.id));
    if(missing.length) {
      truncation=true;
      result.warnings.push('Не прочитаны характеристики отдельных позиций: '+missing.map(p=>`№${p.index} ${p.name} (${p.code})`).join('; '));
    }
    if(result.rows.some(r=>!r.position_id)) {
      truncation=true;
      result.warnings.push('Есть строки без однозначной привязки к товарной позиции.');
    }
  }
  result.completed = result.rows.length>0 && !truncation;
  return result;
};
