// Вкладка ЕИС: только прикреплённые файлы действующей редакции извещения.
// Другие разделы («Разъяснения», «Протоколы» и т.п.) исключаются.
window.__tnDiscoverDocuments = async function () {
  const trim = s => String(s || '').replace(/\s+/g,' ').trim();
  const visible = el => !!(el && el.isConnected && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
  const site = location.hostname.replace(/^www\./,'');
  const base = location.href;
  const docURL = /\.(?:docx?|pdf|rtf|xlsx?|xlsm|odt|ods|zip|rar|7z)(?:$|[?#])|\/filestore\/|\/download\/|[?&](?:download|fileId|attachmentId|fileUid|uid)=|attachment\/download|downloadFile|downloadDocuments/i;
  const unsafe = /javascript:|mailto:|tel:|logout|signout|delete|remove|submitBid|purchase\/apply/i;
  const found = new Set();
  const collect = [];
  const warnings = [];
  let auxiliary_skipped = 0;
  function add(url, title) {
    if (!url || collect.length >= 150) return;
    let link;
    try {link = new URL(url,base);} catch(_) {return;}
    if (!/^https?:$/.test(link.protocol) || unsafe.test(link.href)) return;
    // ЕИС uses listModal.html for signature/information popups.
    // It is HTML, not an attached contract/TZ, even with fileId in the query.
    if (/\/(?:listModal|signModal|signatureModal)\.html$/i.test(link.pathname) ||
        /\.(?:html?|aspx?)$/i.test(link.pathname) && /(?:подпис|сведения|информац|проверить)/i.test(title)) {
      auxiliary_skipped++; return;
    }
    if (!docURL.test(link.href) && !/\.(docx?|pdf|xlsx?|xlsm|zip|rtf|rar|7z)$/i.test(title)) return;
    if (found.has(link.href)) return;
    found.add(link.href);
    collect.push({url:link.href,title:trim(title).slice(0,170)});
  }
  const isEis = /(^|\.)zakupki\.gov\.ru$/i.test(location.hostname);
  const onDocuments = /documents\.html$/i.test(location.pathname);
  if (isEis && onDocuments) {
    // Ограничиваем область между заголовком извещения и заголовком следующего раздела.
    const headingElements = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6,.section-title,.block-title'))
      .filter(visible).filter(el => trim(el.innerText || el.textContent).length < 240);
    const start = headingElements.find(el => /^извещение,?\s+изменение\s+извещения\s+о\s+проведении/i.test(trim(el.innerText||el.textContent)));
    if (!start) return {page:base,site,docs_tab:'',direct_links:[],scope_ok:false,
      warnings:['Не найден раздел «Извещение, изменение извещения». Другие разделы не сканировались.']};
    const isAfter = (node, anchor) => !!(anchor.compareDocumentPosition(node)&Node.DOCUMENT_POSITION_FOLLOWING);
    const next = headingElements.find(el => el!==start && isAfter(el,start));
    const inScope = node => node && isAfter(node,start) && (!next || !!(next.compareDocumentPosition(node)&Node.DOCUMENT_POSITION_PRECEDING));
    function attachmentTags() {
      return [...document.querySelectorAll('div,span,p,small')]
        .filter(el => visible(el) && inScope(el) && /^прикрепл[её]нные\s+файлы$/i.test(trim(el.innerText||el.textContent)));
    }
    const tags = attachmentTags();
    if (!tags.length) return {page:base,site,docs_tab:'',direct_links:[],scope_ok:false,
      warnings:['В действующем разделе извещения не найден блок «Прикрепленные файлы».']};
    // Выбираем минимальный контейнер карточки, включающий «Действующая» и «Прикрепленные файлы».
    // Тем самым не берём архивные редакции и документы от разъяснений.
    let chosen = null, minimum = Infinity;
    for (const tag of tags) {
      let parent = tag;
      for (let depth=0;parent && depth<12;parent=parent.parentElement,depth++) {
        const txt = trim(parent.innerText||parent.textContent);
        if (txt.length > 50000) break;
        if (/(?:^|\s)действующая(?:\s|$)/i.test(txt) && /прикрепл[её]нные\s+файлы/i.test(txt) &&
            parent.querySelectorAll('a[href]').length && inScope(tag)) {
          // Блок не должен включать следующий смысловой раздел.
          const size = txt.length;
          if (size < minimum) {minimum=size;chosen=parent;}
          break;
        }
      }
    }
    if (!chosen) return {page:base,site,docs_tab:'',direct_links:[],scope_ok:false,
      warnings:['Не удалось подтвердить действующую редакцию извещения. Ничего из соседних разделов не скачано.']};
    // Показать больше/ещё — только внутри активной редакции извещения.
    for(let round=0;round<10;round++) {
      const more=[...chosen.querySelectorAll('a,button,[role="button"]')]
        .find(el=>visible(el) && /^показать\s+(больше|ещ[её])$/i.test(trim(el.innerText||el.textContent)));
      if(!more) break;
      more.click();
      await new Promise(resolve=>setTimeout(resolve,400));
    }
    // Берём только ссылки на файлы, стоящие после метки «Прикрепленные файлы».
    const tagsInside=attachmentTags().filter(tag=>chosen.contains(tag));
    const first=tagsInside[0];
    for(const a of chosen.querySelectorAll('a[href]')) {
      if(!visible(a) || !inScope(a)) continue;
      if(first && !isAfter(a,first)) continue;
      add(a.href, trim(a.getAttribute('download')||a.innerText||a.title||a.getAttribute('aria-label')));
    }
    for(const node of chosen.querySelectorAll('[data-href],[data-download-url],[data-url]')) {
      if(!visible(node) || !inScope(node)) continue;
      if(first && !isAfter(node,first)) continue;
      add(node.getAttribute('data-download-url')||node.getAttribute('data-href')||node.getAttribute('data-url'),trim(node.innerText||node.title));
    }
    // Если в блоке есть файл без прямой ссылки, он явно отображается как недоступный.
    if(!collect.length) warnings.push('Вложенные файлы видны, но прямые URL для скачивания не найдены.');
    return {page:base,site,docs_tab:'',direct_links:collect,scope_ok:true,
      current_revision_only:true,warnings,auxiliary_skipped,bulk_button_available:false};
  }
  // Для других площадок — универсальный сборщик по открытой вкладке «Документы».
  for(const a of document.querySelectorAll('a[href]')) {
    if(!visible(a)) continue;
    add(a.href,trim(a.getAttribute('download')||a.innerText||a.title||a.getAttribute('aria-label')||a.closest('tr')?.innerText));
  }
  for(const node of document.querySelectorAll('[data-href],[data-download-url],[data-url]')) {
    if(!visible(node)) continue;
    add(node.getAttribute('data-download-url')||node.getAttribute('data-href')||node.getAttribute('data-url'),trim(node.innerText||node.title));
  }
  let docs_tab='',eis_link='';
  for(const a of document.querySelectorAll('a[href]')) {
    const link=a.href||'';
    if (/^https:\/\/zakupki\.gov\.ru\//i.test(link) && /regNumber=\d{11,19}/i.test(link)) {eis_link=link;break;}
  }
  for(const a of document.querySelectorAll('a[href]')) {
    const label=trim(a.innerText||a.textContent);
    if(/^(документы|документация|документы закупки)$/i.test(label)&&/^https?:\/\//.test(a.href)){docs_tab=a.href;break;}
  }
  return {page:base,site,docs_tab,eis_link,direct_links:collect,scope_ok:true,warnings,auxiliary_skipped};
};
window.__tnClickDocumentsTab = function () {
  for(const el of document.querySelectorAll('button,[role="tab"]')) {
    if(!el.getClientRects().length) continue;
    if(/^(документы|документация|документы закупки)$/i.test(String(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim())){
      el.click();return true;
    }
  }
  return false;
};
