"""Prepare QX's bundled extension and its separate Edge profile.

An unsigned unpacked extension cannot be silently installed in an ordinary Edge
profile. --load-extension is a best-effort launch hint, not installation proof;
only a verified bridge connection establishes that the extension is running.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
MARKER = '.qx-managed-extension.json'
BRIDGE_ENDPOINT = 'ws://127.0.0.1:18764'


def extension_directory() -> Path:
    from modern import tender_store
    return tender_store.APP_DATA / 'edge-extension'


def edge_profile_directory() -> Path:
    from modern import tender_store
    return tender_store.APP_DATA / 'edge-profile'


def _atomic_write(path: Path, contents: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.qx-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(contents)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def prepare_extension(pairing_token: str | None = None) -> dict:
    """Copy trusted bundled files to a stable per-user path, preserving profile.

    The token is local bridge authentication, never printed or returned. Do not
    delete this directory on application uninstall: Edge references its path.
    """
    source = ROOT / 'browser_extension'
    manifest_path = source / 'manifest.json'
    if not manifest_path.is_file():
        raise RuntimeError('В комплекте QX отсутствует расширение ЕИС.')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('manifest_version') != 3 or not manifest.get('background', {}).get('service_worker'):
        raise ValueError('Некорректный manifest расширения QX.')
    target = extension_directory()
    if target.is_symlink():
        raise ValueError('Папка расширения QX не должна быть символической ссылкой.')
    if target.exists() and any(target.iterdir()) and not (target / MARKER).is_file():
        raise RuntimeError('Папка edge-extension уже содержит сторонние файлы; они не были изменены.')
    # Validate the whole source before changing the retained installation.
    files = {}
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            raise ValueError('Символические ссылки в комплекте расширения запрещены.')
        if path.is_file():
            relative = path.relative_to(source)
            if path.stat().st_size > 10 * 1024 * 1024:
                raise ValueError('Файл расширения превышает допустимый размер.')
            files[str(relative)] = path.read_bytes()
    if sum(map(len, files.values())) > 20 * 1024 * 1024:
        raise ValueError('Комплект расширения превышает допустимый размер.')
    if pairing_token is None:
        from modern.extension_bridge import pairing_token as get_token
        pairing_token = get_token()
    if not isinstance(pairing_token, str) or not 32 <= len(pairing_token) <= 256:
        raise ValueError('Некорректный ключ связи расширения.')
    target.mkdir(parents=True, exist_ok=True)
    for relative, contents in files.items():
        destination = target / relative
        # Refuse malicious/replaced parent links in retained application data.
        if any(parent.is_symlink() for parent in (destination, *destination.parents) if parent != target.parent):
            raise ValueError('Ссылка внутри папки расширения запрещена.')
        if not destination.is_file() or destination.read_bytes() != contents:
            _atomic_write(destination, contents)
    config = {'token': pairing_token, 'endpoint': BRIDGE_ENDPOINT}
    _atomic_write(target / 'qx_bridge_config.json', json.dumps(config).encode('utf-8'))
    digest = hashlib.sha256()
    for name, data in files.items():
        digest.update(name.encode('utf-8') + b'\0' + data)
    _atomic_write(target / MARKER, json.dumps({'version': manifest['version'], 'sha256': digest.hexdigest()}).encode())
    return extension_status()


def extension_status() -> dict:
    target = extension_directory()
    try:
        marker = json.loads((target / MARKER).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        marker = {}
    return {'prepared': bool(marker), 'version': marker.get('version', ''),
            'directory': str(target), 'profile_directory': str(edge_profile_directory()),
            'requires_developer_mode': True,
            'message': 'Файлы расширения подготовлены. Подключение подтверждается только связью с QX.',
            'instructions': ['В отдельном окне Edge для QX откройте edge://extensions.',
                             'Включите «Режим разработчика», нажмите «Загрузить распакованное».',
                             'Выберите папку: ' + str(target),
                             'Вернитесь в QX и дождитесь подтверждения связи расширения.']}


def find_edge() -> Path | None:
    if sys.platform != 'win32':
        return None
    for variable, suffix in (('PROGRAMFILES(X86)', 'Microsoft/Edge/Application/msedge.exe'),
                             ('PROGRAMFILES', 'Microsoft/Edge/Application/msedge.exe'),
                             ('LOCALAPPDATA', 'Microsoft/Edge/Application/msedge.exe')):
        base = os.environ.get(variable)
        if base and (Path(base) / suffix).is_file():
            return Path(base) / suffix
    return None


def _allowed_url(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        if parsed.username or parsed.password:
            return False
        if parsed.scheme == 'https':
            return parsed.hostname in ('zakupki.gov.ru', 'www.zakupki.gov.ru') and parsed.port in (None, 443)
        return (parsed.scheme == 'http' and parsed.hostname == '127.0.0.1' and parsed.port == 18764
                and parsed.path == '/extension-pair' and not parsed.query)
    except (ValueError, TypeError):
        return False


def launch_eis(url: str = 'https://zakupki.gov.ru/', pairing_token: str | None = None) -> dict:
    """Open only EIS or local pairing in a QX-owned Edge profile."""
    if not _allowed_url(url):
        raise ValueError('Разрешён только официальный сайт ЕИС или подключение расширения QX.')
    result = prepare_extension(pairing_token)
    edge = find_edge()
    if edge is None:
        return {**result, 'launched': False, 'error': 'Microsoft Edge не найден. Автозапуск доступен в Windows с установленным Edge.'}
    profile = edge_profile_directory()
    profile.mkdir(parents=True, exist_ok=True)
    arguments = [str(edge), '--user-data-dir=' + str(profile),
                 '--load-extension=' + str(extension_directory()), '--no-first-run', url]
    subprocess.Popen(arguments, close_fds=True)
    return {**result, 'launched': True,
            'message': 'Открыт отдельный профиль Edge для QX. Если расширение не подключилось, загрузите его через режим разработчика по инструкции.'}
