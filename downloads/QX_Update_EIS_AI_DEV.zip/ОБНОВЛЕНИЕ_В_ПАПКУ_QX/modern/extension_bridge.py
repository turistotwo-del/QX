"""Paired browser intake on loopback; never trust filesystem paths from a tab.

Only a paired extension origin may send bounded document bytes. The browser
retains its EIS cookies; neither cookies nor download URLs are saved by QX.
"""
from __future__ import annotations

import asyncio
import base64
import binascii
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
import re
import secrets
import threading
from time import monotonic
from urllib.parse import parse_qs, urlsplit

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from modern import tender_store as store
from modern.eis_document_download import import_downloaded_document, validate_document_url
from modern.eis_public import validate_notice

PORT = 18764
MAX_FILE = 30 * 1024 * 1024
MAX_MESSAGE = 42 * 1024 * 1024
FACT_FIELDS = ('title', 'customer', 'nmck', 'law', 'application_due_on',
               'application_due_time', 'auction_on', 'auction_time', 'results_on',
               'results_time', 'supply_address', 'due_on', 'due_days', 'due_unit',
               'payment_terms', 'warranty', 'security', 'is_quotation')


def _official_page(url, number):
    try:
        p = urlsplit(url)
        return (p.scheme == 'https' and p.hostname == 'zakupki.gov.ru' and
                p.port in (None, 443) and p.username is None and p.password is None and
                parse_qs(p.query).get('regNumber') == [number])
    except (TypeError, ValueError):
        return False


def _date(value):
    match = re.fullmatch(r'(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?:\s+(\d{1,2}):(\d{2}))?', str(value).strip())
    if not match:
        return '', ''
    try:
        parsed = datetime(int(match[3]), int(match[2]), int(match[1]),
                          int(match[4] or 0), int(match[5] or 0))
    except ValueError:
        return '', ''
    return parsed.date().isoformat(), parsed.strftime('%H:%M') if match[4] else ''


def _local_datetime(day, clock, zone):
    match = re.fullmatch(r'\s*(МСК|UTC)(?:\s*([+-])\s*(\d{1,2})(?::([0-5]\d))?)?\s*', zone, re.I)
    if not match: raise ValueError('Неизвестный часовой пояс')
    minutes = 180 if match[1].upper() == 'МСК' else 0
    if match[2]: minutes += (1 if match[2] == '+' else -1) * (int(match[3]) * 60 + int(match[4] or 0))
    if not -12 * 60 <= minutes <= 14 * 60: raise ValueError('Некорректный часовой пояс')
    source = datetime.fromisoformat(day + 'T' + clock).replace(tzinfo=timezone(timedelta(minutes=minutes)))
    local = source.astimezone()
    return local.date().isoformat(), local.strftime('%H:%M')


def merge_snapshot(tender_id, snapshot, number):
    """Fill empty card fields atomically, preserving edits and date/time pairs."""
    if not isinstance(snapshot, dict) or snapshot.get('number') != number or not _official_page(snapshot.get('url'), number):
        raise ValueError('Страница расширения не соответствует номеру закупки ЕИС')
    fields = {k: snapshot[k] for k in FACT_FIELDS if snapshot.get(k) not in ('', None)}
    if not (snapshot.get('is_quotation') is True and
            re.search(r'запрос\s+котировок', str(snapshot.get('procedure', '')), re.I)):
        fields.pop('is_quotation', None)
    source_warnings, source_audit = [], []
    for old, new in (('place', 'supply_address'), ('price', 'nmck')):
        if snapshot.get(old) and new not in fields:
            fields[new] = snapshot[old]
    if 'nmck' in fields:
        amount = str(fields['nmck']).replace('\xa0', '').replace('\u202f', '').replace(' ', '').replace(',', '.')
        if re.fullmatch(r'\d+(?:\.\d{1,2})?', amount): fields['nmck'] = amount
        else: fields.pop('nmck')
    for key, target in (('deadline', 'application_due'), ('auction_date', 'auction'), ('results_date', 'results')):
        day, clock = _date(snapshot.get(key, ''))
        if day:
            fields[target + '_on'] = day
            zone_key = {'deadline': 'deadline_timezone', 'auction_date': 'auction_timezone', 'results_date': 'results_timezone'}[key]
            zone = str(snapshot.get(zone_key, ''))[:30]
            if clock and zone:
                try:
                    local_day, local_clock = _local_datetime(day, clock, zone)
                    fields[target + '_on'], fields[target + '_time'] = local_day, local_clock
                    source_audit.append(f'{target}: источник {day} {clock} ({zone}); местное время {local_day} {local_clock}')
                except ValueError:
                    fields.pop(target + '_time', None)
                    source_warnings.append(f'{target}: время источника {clock} ({zone}); укажите местное время после проверки часового пояса')
            elif clock: fields[target + '_time'] = clock
    # Validate independently: a malformed optional field must not discard other facts.
    values, warnings = {}, source_warnings
    for key, value in fields.items():
        try: values.update(store._validate({key: value}))
        except (ValueError, TypeError, OverflowError): warnings.append('Не принято поле: ' + key)
    applied, conflicts = [], []
    with store.transaction() as conn:
        current = conn.execute('SELECT * FROM tenders WHERE id=?', (tender_id,)).fetchone()
        if current is None or current['number'] != number:
            raise ValueError('Карточка не соответствует номеру закупки')
        fill_relative_days = not current['due_days'] and not current['due_on'] and bool(values.get('due_days'))
        for field, value in values.items():
            old = current[field]
            if field == 'is_quotation' and (current['auction_on'] or current['auction_time']):
                conflicts.append({'field': field, 'current': old, 'received': value, 'reason': 'В карточке уже сохранён аукцион'})
                continue
            if field in ('due_days', 'due_unit') and not fill_relative_days:
                if str(old) != str(value): conflicts.append({'field': field, 'current': old, 'received': value})
                continue
            if field.endswith('_time'):
                day_field = field[:-5] + '_on'
                if current[day_field] and current[day_field] != values.get(day_field):
                    conflicts.append({'field': field, 'current': old, 'received': value})
                    continue
            if old in ('', None) or field in ('nmck', 'is_quotation') and old == 0 or field in ('due_days', 'due_unit') and fill_relative_days:
                conn.execute(f'UPDATE tenders SET {field}=?,updated_at=? WHERE id=?', (value, store.now(), tender_id))
                applied.append(field)
            elif str(old) != str(value): conflicts.append({'field': field, 'current': old, 'received': value})
        if applied:
            conn.execute('INSERT INTO tender_events(tender_id,label,created_at) VALUES(?,?,?)',
                         (tender_id, 'ЕИС через расширение: ' + ', '.join(applied) +
                          '; источник: https://zakupki.gov.ru/ (извещение ' + number + ')', store.now()))
        for warning in source_warnings + source_audit:
            conn.execute('INSERT INTO tender_events(tender_id,label,created_at) VALUES(?,?,?)',
                         (tender_id, 'ЕИС через расширение: ' + warning, store.now()))
    return applied, conflicts, warnings


class ExtensionBridge:
    def __init__(self):
        self.app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
        self._token = None
        self._lock = threading.RLock()
        self._ws = None
        self._loop = None
        self._jobs = {}
        self._active = None
        self._server = None
        self._thread = None
        self._version = ''
        self._failure = ''
        self.app.get('/extension-pair', response_class=HTMLResponse)(self._pair_page)
        self.app.websocket('/')(self._connection)

    def pairing_token(self):
        # Reuse the same pairing across QX/Edge restarts. Never store this in
        # the checkout or put it in query parameters, logs, or diagnostics.
        with self._lock:
            if self._token is None:
                path = store.APP_DATA / 'extension-pairing.token'
                store.APP_DATA.mkdir(parents=True, exist_ok=True)
                if path.is_symlink(): raise ValueError('Небезопасный файл подключения расширения')
                try:
                    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                except FileExistsError:
                    token = path.read_text(encoding='ascii').strip()
                    if not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
                        raise ValueError('Повреждён файл подключения расширения')
                else:
                    token = secrets.token_urlsafe(32)
                    with os.fdopen(fd, 'w', encoding='ascii') as stream: stream.write(token)
                self._token = token
            return self._token

    def status(self):
        with self._lock:
            return {'running': bool(self._server and self._server.started),
                    'connected': self._ws is not None, 'extension_version': self._version,
                    'message': self._failure or ('Расширение подключено' if self._ws else 'Расширение не подключено'),
                    'pairing_url': f'http://127.0.0.1:{PORT}/extension-pair#token={self.pairing_token()}',
                    'active_job': self._active}

    async def _pair_page(self):
        return '<!doctype html><meta charset="utf-8"><title>QX — подключение расширения</title><h1>QX LOTECTOR</h1><p id="state">Подключаю расширение QX… Если статус не меняется, загрузите папку расширения через режим разработчика Edge.</p>'

    def start(self):
        import uvicorn
        with self._lock:
            if self._thread and self._thread.is_alive(): return self.status()
            self._failure = ''
            config = uvicorn.Config(self.app, host='127.0.0.1', port=PORT,
                                    log_level='warning', access_log=False,
                                    ws_max_size=MAX_MESSAGE, ws_max_queue=2)
            self._server = uvicorn.Server(config)
            def run():
                try: self._server.run()
                except (SystemExit, OSError):
                    with self._lock: self._failure = 'Не удалось запустить связь с расширением: проверьте, свободен ли порт 18764'
            self._thread = threading.Thread(target=run, daemon=True, name='qx-extension')
            self._thread.start()
        return self.status()

    def stop(self):
        if self._server: self._server.should_exit = True

    def start_job(self, number, tender_id=''):
        number = validate_notice(number)
        with self._lock:
            if not self._ws or not self._loop: raise ValueError('Сначала подключите расширение QX в Edge')
            if self._active: raise ValueError('Загрузка через расширение уже выполняется')
            if tender_id:
                tender = store.get(tender_id)
                if not tender or tender['number'] != number: raise ValueError('Номер не совпадает с выбранной карточкой')
            else:
                matches = [t for t in store.listing() if t['number'] == number]
                if len(matches) > 1: raise ValueError('Выберите нужную карточку закупки')
                tender = matches[0] if matches else store.create({'number': number})
                tender_id = tender['id']
            jid = secrets.token_hex(16)
            job = {'id': jid, 'number': number, 'tender_id': tender_id, 'state': 'queued',
                   'message': 'Открываю ЕИС в браузере', 'found': 0, 'imported': 0,
                   'duplicates': 0, 'errors': [], 'warnings': [], 'fields_applied': [],
                   'conflicts': [], 'files': [], 'complete': False, '_claims': {},
                   '_bytes': 0, '_started': monotonic()}
            # Keep a bounded history of completed jobs.
            while len(self._jobs) >= 30: self._jobs.pop(next(iter(self._jobs)))
            self._jobs[jid] = job
            self._active = jid
            notice_path = 'ea20/view' if len(number) == 19 else 'notice223'
            future = asyncio.run_coroutine_threadsafe(self._ws.send_json({'type': 'documents', 'id': jid,
                    'number': number, 'url': f'https://zakupki.gov.ru/epz/order/notice/{notice_path}/common-info.html?regNumber=' + number}), self._loop)
            def on_sent(done):
                try: done.result()
                except Exception:
                    with self._lock:
                        job['state'] = 'failed'; job['errors'].append('Связь с расширением прервана'); self._active = None
            future.add_done_callback(on_sent)
            return self.job_status(jid)

    def job_status(self, jid):
        with self._lock:
            if jid not in self._jobs: raise KeyError('Загрузка не найдена')
            return deepcopy({k: v for k, v in self._jobs[jid].items() if not k.startswith('_')})

    async def _connection(self, ws: WebSocket):
        origin = ws.headers.get('origin', '')
        if not re.fullmatch(r'chrome-extension://[a-p]{32}', origin):
            await ws.close(code=1008); return
        await ws.accept()
        paired = False
        try:
            hello = await asyncio.wait_for(ws.receive_json(), timeout=5)
            if not isinstance(hello, dict) or hello.get('type') != 'hello' or not secrets.compare_digest(str(hello.get('token', '')), self.pairing_token()):
                await ws.close(code=1008); return
            with self._lock:
                if self._ws is not None:
                    await ws.close(code=1008); return
                self._ws, self._loop = ws, asyncio.get_running_loop()
                self._version = str(hello.get('version', ''))[:40]
                paired = True
            await ws.send_json({'type': 'paired'})
            while True:
                message = await asyncio.wait_for(ws.receive_json(), timeout=180)
                if isinstance(message, dict): await self._message(ws, message)
        except (WebSocketDisconnect, asyncio.TimeoutError, ValueError, RuntimeError, TypeError):
            pass
        finally:
            if paired:
                with self._lock:
                    self._ws = None
                    if self._active:
                        job = self._jobs[self._active]
                        job['state'] = 'partial' if job['imported'] or job['fields_applied'] else 'failed'
                        job['errors'].append('Связь с расширением прервана; сохранённые файлы остаются в карточке')
                        self._active = None
                        self._request_analysis(job)

    def _request_analysis(self, job):
        if job['imported'] and not job.get('document_ai'):
            try:
                from modern.document_ai import submit
                job['document_ai'] = submit(job['tender_id'])
            except (ImportError, ValueError, RuntimeError, KeyError, OSError) as e:
                job['warnings'].append('Анализ документов: ' + str(e)[:180])

    async def _message(self, ws, msg):
        with self._lock:
            if self._active and monotonic() - self._jobs[self._active]['_started'] > 1800:
                expired = self._jobs[self._active]
                expired['state'] = 'partial' if expired['imported'] or expired['fields_applied'] else 'failed'
                expired['errors'].append('Превышено время загрузки'); self._active = None
                self._request_analysis(expired)
            job = self._jobs.get(msg.get('id'))
            if not job or self._active != job['id']: return
            if monotonic() - job['_started'] > 1800:
                job['state'] = 'partial'; job['errors'].append('Превышено время загрузки'); self._active = None; return
            kind = msg.get('type')
            if kind == 'progress':
                job['state'] = 'running'; job['message'] = str(msg.get('message', ''))[:500]
            elif kind == 'snapshot':
                try:
                    applied, conflicts, warnings = merge_snapshot(job['tender_id'], msg.get('data'), job['number'])
                    job['fields_applied'].extend(x for x in applied if x not in job['fields_applied'])
                    job['conflicts'].extend(conflicts); job['warnings'].extend(warnings)
                except ValueError as e: job['errors'].append(str(e))
            elif kind == 'file_claim':
                decision = {'action': 'busy'}
                try:
                    url = validate_document_url(msg.get('url'))
                    if len(job['_claims']) >= 100: raise ValueError('Лимит 100 документов')
                    claim = job['_claims'].get(url)
                    if claim and claim['state'] == 'done': decision = {'action': 'skip'}
                    elif not claim or claim['state'] == 'error':
                        token = secrets.token_hex(20)
                        job['_claims'][url] = {'token': token, 'state': 'claimed'}
                        decision = {'action': 'download', 'claim_token': token}
                except (ValueError, TypeError): decision = {'action': 'denied'}
                await ws.send_json({'type': 'file_claim_result', 'request_id': str(msg.get('request_id', ''))[:60], 'decision': decision})
            elif kind == 'file_upload':
                reply = {'type': 'file_import_result', 'request_id': str(msg.get('request_id', ''))[:60], 'ok': False}
                try:
                    url = validate_document_url(msg.get('url'))
                    claim = job['_claims'].get(url)
                    if not claim or claim['state'] != 'claimed' or not secrets.compare_digest(str(msg.get('claim_token', '')), claim['token']):
                        raise ValueError('Документ не зарезервирован')
                    encoded = msg.get('data')
                    if not isinstance(encoded, str) or len(encoded) > ((MAX_FILE + 2) // 3) * 4: raise ValueError('Файл больше 30 МБ')
                    data = base64.b64decode(encoded, validate=True)
                    if not data or len(data) > MAX_FILE or job['_bytes'] + len(data) > 120 * 1024 * 1024: raise ValueError('Превышен лимит размера документов')
                    if not secrets.compare_digest(hashlib.sha256(data).hexdigest(), str(msg.get('sha256', ''))): raise ValueError('Не совпала контрольная сумма документа')
                    name = str(msg.get('filename', ''))[:220]
                    result = import_downloaded_document(job['tender_id'], name, data, source_label='ЕИС через расширение QX')
                    job['_bytes'] += len(data); claim['state'] = 'done'
                    imported, duplicates = len(result['imported']), len(result['duplicates'])
                    job['imported'] += imported; job['duplicates'] += duplicates
                    job['warnings'].extend(str(x.get('reason', '')) for x in result.get('warnings', []))
                    job['files'].append({'name': name, 'status': 'imported' if imported else 'duplicate'})
                    reply['ok'] = True
                except (ValueError, TypeError, KeyError, binascii.Error, OSError) as e:
                    reply['error'] = str(e)[:300]; job['errors'].append(reply['error'])
                await ws.send_json(reply)
            elif kind == 'file_progress':
                file = msg.get('file') or {}
                if isinstance(file, dict) and file.get('state') == 'error':
                    job['files'].append({'name': str(file.get('title', ''))[:200], 'status': 'failed', 'error': str(file.get('error', ''))[:300]})
            elif kind == 'result':
                result = msg.get('data') or {}
                if msg.get('error'): job['errors'].append(str(msg['error'])[:500])
                if isinstance(result, dict):
                    found = result.get('count_found', 0)
                    job['found'] = found if type(found) is int and 0 <= found <= 10000 else 0
                    job['errors'].extend(str(x)[:500] for x in (result.get('errors') or [])[:120])
                    # Store structured EIS tables as a readable original, independent of file failures.
                    eis = result.get('eis')
                    if isinstance(eis, dict) and (eis.get('rows') or eis.get('positions')):
                        text = json.dumps(eis, ensure_ascii=False, indent=2).encode()
                        if len(text) <= MAX_FILE:
                            store.add_document(job['tender_id'], 'ЕИС_характеристики.json.txt', text, text.decode()[:30000])
                    confirmed = sum(1 for c in job['_claims'].values() if c['state'] == 'done')
                    job['complete'] = bool(job['found'] and confirmed == job['found'] and not job['errors'])
                job['state'] = 'complete' if job['complete'] else 'partial' if job['imported'] or job['duplicates'] or job['fields_applied'] else 'failed'
                job['message'] = 'Документы сохранены' if job['complete'] else 'Загрузка завершена с замечаниями'
                self._active = None
                self._request_analysis(job)


bridge = ExtensionBridge()


def pairing_token():
    return bridge.pairing_token()


def start():
    return bridge.start()


def stop():
    return bridge.stop()


def status():
    return bridge.status()


def start_job(number, tender_id=''):
    return bridge.start_job(number, tender_id)


def job_status(jid):
    return bridge.job_status(jid)
