"""Coalesced, local background document review with conservative blank autofill.

Files and application logic stay in QX. No external AI endpoint is used.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from threading import RLock

from modern import tender_store as store
from modern.tender_analysis import analyze_documents
from modern.contract_autofill import extract, blank_fields
from modern.local_ai import scan_document_facts

_POOL=ThreadPoolExecutor(max_workers=1,thread_name_prefix='qx-documents')
_LOCK=RLock()
_JOBS={}

def _key(tender_id):
    if not isinstance(tender_id,str) or not re.fullmatch(r'[\w-]{1,80}',tender_id):
        raise ValueError('Некорректный идентификатор закупки')
    return (str(store.DB_FILE.resolve()),tender_id)

def _path(tender_id):
    _key(tender_id)
    return store.APP_DATA/'document_analysis'/(tender_id+'.json')

def _save(tender_id, result):
    path=_path(tender_id);path.parent.mkdir(parents=True,exist_ok=True)
    fd, name=tempfile.mkstemp(prefix='.analysis-',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as handle:
            json.dump(result,handle,ensure_ascii=False)
        os.replace(name,path)
    finally:
        Path(name).unlink(missing_ok=True)

def _fingerprint(rows):
    return hashlib.sha256(json.dumps(sorted((d['id'],d['sha256']) for d in rows)).encode()).hexdigest()


def _current_fingerprint(tender_id):
    with store.connection() as con:
        rows=con.execute('SELECT id,sha256 FROM tender_documents WHERE tender_id=?',(tender_id,)).fetchall()
    return _fingerprint(rows)


def status(tender_id):
    key=_key(tender_id)
    value=None
    with _LOCK:
        job=_JOBS.get(key)
        if job:
            payload={k:v for k,v in job.items() if k not in ('future','dirty')}
            if job['state']!='complete':return payload
            value=payload.get('result')
    if value is None:
        try:value=json.loads(_path(tender_id).read_text(encoding='utf-8'))
        except (OSError,ValueError,TypeError):return {'state':'idle','result':None}
    if not isinstance(value,dict) or not value.get('source_fingerprint'):
        return {'state':'idle','result':None}
    if value.get('stale') or value['source_fingerprint']!=_current_fingerprint(tender_id):
        # Deleted/replaced attachments invalidate both in-memory and restored
        # reports. Do not display old findings as if they describe current files.
        return {'state':'stale','result':None,
                'message':'Состав документов изменился. Повторите анализ текущих файлов.'}
    return {'state':'complete','result':value}

def submit(tender_id):
    """Schedule after import/upload; never hold up the HTTP upload response."""
    key=_key(tender_id)
    if not store.get(tender_id):raise KeyError('Закупка не найдена')
    with _LOCK:
        job=_JOBS.get(key)
        if job and job.get('state') in ('queued','running'):
            job['dirty']=True
            return {'state':job['state']}
        if sum(j.get('state') in ('queued','running') for j in _JOBS.values())>=100:
            return {'state':'busy','message':'Очередь анализа заполнена. Повторите анализ позже.'}
        _JOBS[key]={'state':'queued','result':None,'dirty':False}
        _JOBS[key]['future']=_POOL.submit(_work,key)
    return {'state':'queued'}

def _same_database(key):
    return str(store.DB_FILE.resolve())==key[0]

def _work(key):
    while True:
        with _LOCK:
            _JOBS[key]['state']='running';_JOBS[key]['dirty']=False
        if not _same_database(key):
            with _LOCK:_JOBS[key].update(state='cancelled',message='База данных изменилась')
            return
        try:
            result=run(key[1],expected_database=key[0])
            with _LOCK:_JOBS[key]['result']=result
        except Exception as exc:
            with _LOCK:_JOBS[key].update(state='error',message=str(exc)[:240])
            return
        with _LOCK:
            if not _JOBS[key]['dirty']:
                _JOBS[key]['state']='complete'
                # Keep bounded in-memory history. Persistent reports stay on disk.
                done=[k for k,j in _JOBS.items() if j.get('state') not in ('queued','running')]
                for old in done[:-150]:_JOBS.pop(old,None)
                return

def run(tender_id, *, expected_database=None):
    """Run synchronously for tests/CLI; apply only unambiguous empty fields."""
    key=_key(tender_id)
    if expected_database is not None and key[0]!=expected_database:
        raise RuntimeError('База данных изменилась')
    item=store.detail(tender_id)
    docs=[];errors=[]
    for doc in item['documents']:
        if doc['filename'].lower().endswith('.qxproj'):continue
        try:docs.append(store.document_bytes(tender_id,doc['id']))
        except (OSError,ValueError,KeyError) as exc:errors.append({'file':doc['filename'],'error':str(exc)[:160]})
    fingerprint=_fingerprint(item['documents'])
    analysis=analyze_documents(docs)
    contract=extract(docs,use_local_ai=False)
    model=scan_document_facts(docs) if docs else {'state':'no_evidence','model':None,'attempted':False,'facts':[],'message':'Документы не загружены'}
    errors+=analysis.get('errors',[])+contract.get('errors',[])
    if errors:
        analysis['bios']['status']='Требуется уточнение: не все документы удалось проверить'
    analysis['suggested_fields']=contract['verified']
    analysis['contract_disputes']=list(contract['disputed'])
    applied=[];conflicts=[]
    # A model may take a minute: re-read source identity and manual card values
    # in the write transaction, so neither new files nor user edits are raced.
    if not _same_database(key):raise RuntimeError('База данных изменилась')
    with store.transaction() as con:
        current=con.execute('SELECT * FROM tenders WHERE id=?',(tender_id,)).fetchone()
        if current is None:raise KeyError('Закупка удалена')
        current=dict(current)
        rows=con.execute('SELECT id,sha256 FROM tender_documents WHERE tender_id=?',(tender_id,)).fetchall()
        fresh=_fingerprint(rows)
        stale=fingerprint!=fresh
        updates=blank_fields(current,contract['verified']) if not errors and not stale else {}
        for field in contract['disputed']:updates.pop(field,None)
        if 'due_days' in contract['disputed'] or 'due_unit' in contract['disputed']:
            updates.pop('due_days',None);updates.pop('due_unit',None)
        if updates.get('due_on') and updates.get('due_days'):
            updates.pop('due_days',None);updates.pop('due_unit',None)
        # An explicit date and a contract-relative term are different deadline
        # definitions. Preserve pre-existing deadlines, regardless of blank part.
        if current.get('due_on'):
            updates.pop('due_days',None);updates.pop('due_unit',None)
        if current.get('due_days'):updates.pop('due_on',None)
        for entry in contract['verified']:
            field=entry['field'];old=current.get(field)
            if old not in ('',None,0) and old!=entry['value'] and field!='due_unit':
                conflicts.append({'field':field,'current':old,'proposed':entry['value'],'evidence':entry['evidence']})
        if updates:
            updates=store._validate(updates)
            con.execute('UPDATE tenders SET '+','.join(f'{f}=?' for f in updates)+',updated_at=? WHERE id=?',
                        [*updates.values(),store.now(),tender_id])
            for entry in contract['verified']:
                if entry['field'] in updates:
                    proof=entry['evidence']
                    con.execute('INSERT INTO tender_events(tender_id,label,created_at) VALUES(?,?,?)',
                        (tender_id,'Автозаполнение '+entry['field']+' из '+proof['file']+' ('+proof['location']+')',store.now()))
            applied=list(updates)
    result={'analysis':analysis,'model':model,'applied':applied,'conflicts':conflicts,
            'disputed':contract['disputed'],'errors':errors,'stale':stale,
            'source_fingerprint':fingerprint,'updated_at':datetime.now(timezone.utc).isoformat()}
    if not stale:_save(tender_id,result)
    return result
