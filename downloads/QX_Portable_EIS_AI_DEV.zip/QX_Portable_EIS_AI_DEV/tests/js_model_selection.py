"""Execute the browser's model selection function with controlled local status."""
import json
from pathlib import Path
import subprocess


def select_models(models, selected=''):
    root=Path(__file__).resolve().parents[1]
    source=(root/'modern/web/app.js').read_text(encoding='utf-8')
    begin=source.index('async function refreshTenderAiStatus()')
    end=source.index('async function handleTenderAction(',begin)
    function=source[begin:end]
    harness='''
const state={tenders:{detailTab:'overview'},tab:'home',tzAiModel:SELECTED,tenderAiModel:'offline-search'};
const api=async path => path==='local-ai/status' ? {models:MODELS} : {state:'idle'};
const render=()=>{};
'''.replace('SELECTED',json.dumps(selected)).replace('MODELS',json.dumps(models))
    result=subprocess.run(['node','--input-type=module','-'],input=harness+function+'\nawait refreshTenderAiStatus(); console.log(JSON.stringify(state));',text=True,capture_output=True,check=True)
    return json.loads(result.stdout)
