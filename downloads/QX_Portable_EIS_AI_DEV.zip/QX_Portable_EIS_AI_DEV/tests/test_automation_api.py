"""Exercise upload -> automatic review -> persisted report through real HTTP API.

Only the local model discovery/inference boundary is mocked; SQLite, document
parsing, worker scheduling, and card updates run normally.
"""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import tempfile
from threading import Event
import time
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient
from modern import document_ai as ai, local_ai, tender_store as store
from modern.server import app


class AutomaticDocumentAPI(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='qx-auto-api-')
        self.old=(store.APP_DATA,store.DB_FILE,store.DOCUMENTS,store._INITIALIZED)
        store.APP_DATA=Path(self.tmp.name)
        store.DB_FILE=store.APP_DATA/'tenders.sqlite3'
        store.DOCUMENTS=store.APP_DATA/'documents'
        store._INITIALIZED=False
        store.initialize()
        # Every test owns its worker and drains it before restoring module-level
        # store paths. This avoids writing into the next test's temporary DB.
        self.worker=ThreadPoolExecutor(max_workers=1,thread_name_prefix='qx-test-auto')
        self.pool_patch=patch.object(ai,'_POOL',self.worker)
        self.jobs_patch=patch.object(ai,'_JOBS',{})
        self.models_patch=patch.object(local_ai,'available_models',return_value={'models':[]})
        for p in (self.pool_patch,self.jobs_patch,self.models_patch):p.start()
        self.client=TestClient(app)
        self.release=Event()

    def tearDown(self):
        self.release.set()
        self.worker.shutdown(wait=True,cancel_futures=False)
        self.client.close()
        for p in (self.models_patch,self.jobs_patch,self.pool_patch):p.stop()
        store.APP_DATA,store.DB_FILE,store.DOCUMENTS,store._INITIALIZED=self.old
        self.tmp.cleanup()

    def create(self,**fields):
        response=self.client.post('/api/tenders',json={'title':'Проверка автоматизации',**fields})
        self.assertEqual(response.status_code,200,response.text)
        return response.json()['tender']['id']

    def upload(self,tid,text,name='Контракт.txt'):
        from urllib.parse import quote
        return self.client.post(f'/api/tenders/{tid}/documents',content=text.encode(),
                                headers={'x-file-name':quote(name)})

    def wait_complete(self,tid):
        deadline=time.monotonic()+6
        while time.monotonic()<deadline:
            r=self.client.get(f'/api/tenders/{tid}/document-ai')
            self.assertEqual(r.status_code,200,r.text)
            status=r.json()
            if status['state'] not in ('queued','running'):
                self.assertEqual(status['state'],'complete',status)
                return status['result']
            self.release.wait(.02)
        self.fail('Automatic document review did not complete')

    def test_upload_automatically_fills_blanks_preserves_manual_and_restores_report(self):
        tid=self.create(warranty='36 месяцев')
        upload=self.upload(tid,
            'Срок поставки: в течение 25 рабочих дней со дня заключения контракта.\n'
            'Оплата в течение 7 рабочих дней после подписания документа о приёмке.\n'
            'Гарантийный срок: 24 месяца.\n'
            'BIOS должен быть включён в реестр российского программного обеспечения.')
        self.assertEqual(upload.status_code,200,upload.text)
        self.assertIn(upload.json()['document_ai']['state'],('queued','running','complete'))
        result=self.wait_complete(tid)
        current=store.get(tid)
        self.assertEqual(current['due_days'],25)
        self.assertEqual(current['due_unit'],'work')
        self.assertIn('7 рабочих дней',current['payment_terms'])
        self.assertEqual(current['warranty'],'36 месяцев')
        self.assertIn('warranty',[x['field'] for x in result['conflicts']])
        self.assertEqual(result['model']['state'],'unavailable')
        self.assertFalse(result['model']['attempted'])
        self.assertIn('BIOS',result['analysis']['bios']['status'])
        proof=next(p['evidence'] for p in result['analysis']['suggested_fields'] if p['field']=='due_days')
        self.assertEqual(proof['file'],'Контракт.txt');self.assertIn('строка',proof['location'])
        path=store.APP_DATA/'document_analysis'/(tid+'.json')
        self.assertEqual(json.loads(path.read_text(encoding='utf-8'))['source_fingerprint'],result['source_fingerprint'])
        with ai._LOCK:ai._JOBS.clear()
        restored=self.client.get(f'/api/tenders/{tid}/document-ai').json()
        self.assertEqual(restored['state'],'complete')
        self.assertEqual(restored['result']['applied'],result['applied'])

    def test_inference_does_not_block_upload_or_health(self):
        tid=self.create()
        started=Event()
        def inference(*args,**kwargs):
            started.set()
            if not self.release.wait(5):raise RuntimeError('test inference was not released')
            return '{"facts":[]}'
        with patch.object(local_ai,'available_models',return_value={'models':[local_ai.LITE_MODEL]}),\
             patch.object(local_ai,'_lite_answer',side_effect=inference),\
             ThreadPoolExecutor(max_workers=1) as http:
            try:
                future=http.submit(self.upload,tid,'Оплата в течение 7 рабочих дней после приёмки.')
                upload=future.result(timeout=2)
                self.assertEqual(upload.status_code,200,upload.text)
                self.assertTrue(started.wait(2),'The actual background model adapter was not reached')
                health=http.submit(self.client.get,'/api/health').result(timeout=2)
                self.assertEqual(health.status_code,200)
                self.assertTrue(health.json()['ok'])
                self.assertFalse(self.release.is_set())
                state=self.client.get(f'/api/tenders/{tid}/document-ai').json()
                self.assertEqual(state['state'],'running')
            finally:self.release.set()
            result=self.wait_complete(tid)
        self.assertTrue(result['model']['attempted'])
        self.assertEqual(result['model']['state'],'complete')
        self.assertEqual(result['model']['facts'],[])

    def test_removed_document_invalidates_in_memory_and_persisted_findings(self):
        tid=self.create()
        uploaded=self.upload(tid,'Оплата в течение 7 рабочих дней после приёмки.').json()
        self.wait_complete(tid)
        store.remove_document(tid,uploaded['document_id'])
        status=self.client.get(f'/api/tenders/{tid}/document-ai').json()
        self.assertEqual(status['state'],'stale');self.assertIsNone(status['result'])
        with ai._LOCK:ai._JOBS.clear()
        restored=self.client.get(f'/api/tenders/{tid}/document-ai').json()
        self.assertEqual(restored['state'],'stale');self.assertIsNone(restored['result'])

    def test_blank_document_cannot_produce_fully_checked_bios_or_fill(self):
        tid=self.create()
        # A valid Word file containing only an empty paragraph simulates a
        # document whose content requires OCR. The parser must report this.
        from docx import Document
        from io import BytesIO
        from urllib.parse import quote
        doc=Document();stream=BytesIO();doc.save(stream)
        r=self.client.post(f'/api/tenders/{tid}/documents',content=stream.getvalue(),
                           headers={'x-file-name':quote('Скан.docx')})
        self.assertEqual(r.status_code,200,r.text)
        result=self.wait_complete(tid)
        self.assertTrue(result['errors'])
        self.assertEqual(result['applied'],[])
        self.assertIn('не все документы',result['analysis']['bios']['status'])
