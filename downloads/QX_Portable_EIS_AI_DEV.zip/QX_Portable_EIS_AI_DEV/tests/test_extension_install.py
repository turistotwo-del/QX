"""Preparation is repeatable and Edge launch never touches a personal profile."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import importlib
from contextlib import redirect_stderr
from io import StringIO

from modern import extension_install as install
import qx_entry


class ExtensionInstallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'bundle' / 'browser_extension'
        self.source.mkdir(parents=True)
        (self.source / 'manifest.json').write_text(json.dumps({
            'manifest_version': 3, 'version': '1.15.0',
            'background': {'service_worker': 'background.js'}}))
        (self.source / 'background.js').write_text('console.log("extension");')
        self.destination = self.root / 'data' / 'edge-extension'
        self.profile = self.root / 'data' / 'edge-profile'
        for name, value in [('ROOT', self.source.parent)]:
            p = patch.object(install, name, value); p.start(); self.addCleanup(p.stop)
        for name, value in [('extension_directory', self.destination), ('edge_profile_directory', self.profile)]:
            p = patch.object(install, name, return_value=value); p.start(); self.addCleanup(p.stop)
        self.token = 'x' * 48

    def test_repeatable_preparation_and_upgrade_preserves_edge_profile(self):
        self.profile.mkdir(parents=True)
        personal = self.profile / 'Preferences'
        personal.write_text('keep')
        first = install.prepare_extension(self.token)
        second = install.prepare_extension(self.token)
        self.assertTrue(first['prepared'])
        self.assertEqual(first, second)
        self.assertNotIn(self.token, str(first))
        self.assertEqual(json.loads((self.destination / 'qx_bridge_config.json').read_text())['token'], self.token)
        (self.source / 'background.js').write_text('console.log("new version");')
        install.prepare_extension(self.token)
        self.assertIn('new version', (self.destination / 'background.js').read_text())
        self.assertEqual(personal.read_text(), 'keep')

    def test_foreign_existing_directory_is_preserved(self):
        self.destination.mkdir(parents=True)
        existing = self.destination / 'notes.txt'
        existing.write_text('do not remove')
        with self.assertRaises(RuntimeError):
            install.prepare_extension(self.token)
        self.assertEqual(existing.read_text(), 'do not remove')

    def test_symlinked_source_is_rejected_before_installing(self):
        link = self.source / 'outside.js'
        try:
            link.symlink_to(self.root / 'private')
        except OSError:
            self.skipTest('symlinks unavailable')
        with self.assertRaises(ValueError):
            install.prepare_extension(self.token)
        self.assertFalse(self.destination.exists())

    def test_edge_launch_is_bounded_to_dedicated_profile(self):
        edge = self.root / 'msedge.exe'
        with patch.object(install, 'find_edge', return_value=edge), patch.object(install.subprocess, 'Popen') as popen:
            result = install.launch_eis('https://zakupki.gov.ru/epz/order/notice/ea44/view/common-info.html?regNumber=0325100013726000029', self.token)
        self.assertTrue(result['launched'])
        args = popen.call_args.args[0]
        self.assertIn('--user-data-dir=' + str(self.profile), args)
        self.assertIn('--load-extension=' + str(self.destination), args)
        self.assertNotIn('connected', result)
        self.assertTrue(result['requires_developer_mode'])

    def test_rejects_arbitrary_browser_targets(self):
        for url in ('file:///C:/private.txt', 'javascript:alert(1)', 'https://zakupki.gov.ru.evil.test/',
                    'https://user@zakupki.gov.ru/', 'http://127.0.0.1:18764/api/private',
                    'http://127.0.0.1:18764/extension-pair?token=secret'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                install.launch_eis(url, self.token)

    def test_non_windows_reports_no_launch(self):
        with patch.object(install, 'find_edge', return_value=None):
            result = install.launch_eis(pairing_token=self.token)
        self.assertFalse(result['launched'])
        self.assertTrue(result['prepared'])

    def test_old_portable_runtime_without_websockets_requires_repair(self):
        real_import = importlib.import_module
        def missing(module, *args, **kwargs):
            if module == 'websockets':
                raise ModuleNotFoundError('missing WebSocket transport')
            return real_import(module, *args, **kwargs)
        with patch('importlib.import_module', side_effect=missing), redirect_stderr(StringIO()):
            self.assertEqual(qx_entry.eis_dependency_selfcheck(), 1)


if __name__ == '__main__':
    unittest.main()
