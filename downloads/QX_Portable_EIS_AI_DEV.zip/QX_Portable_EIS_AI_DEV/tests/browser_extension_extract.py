"""Controlled DOM validation of the actual bundled EIS content scripts.

Does not install an extension, bypass browser policy or contact the live EIS.
"""
from pathlib import Path

from playwright.sync_api import sync_playwright
from chromium_launch import launch_chromium

ROOT = Path(__file__).resolve().parents[1]
NUMBER = '0325100013726000029'
BASE = 'https://zakupki.gov.ru/epz/order/notice/ea20/view/'


def content(page, name):
    page.add_script_tag(content=(ROOT / 'browser_extension' / name).read_text('utf-8'))


def main():
    with sync_playwright() as p:
        browser = launch_chromium(p)
        page = browser.new_page()
        # Every document is fulfilled locally; the test exercises DOM code only.
        page.route('https://zakupki.gov.ru/**', lambda route: route.fulfill(
            status=200, content_type='text/html', body='<html><body></body></html>'))
        page.goto(BASE + 'common-info.html?regNumber=' + NUMBER)
        page.set_content('''<main><h1>Закупка оборудования</h1><pre>
Наименование объекта закупки: Поставка компьютерного оборудования
Наименование заказчика: Государственное бюджетное учреждение Тест
Начальная (максимальная) цена контракта: 1 250 000,00
Дата и время окончания подачи заявок: 30.10.2026 09:15
Дата проведения аукциона: 02.11.2026 10:30
Дата подведения итогов: 03.11.2026
Место поставки: г. Москва, улица Тестовая, дом 1
Срок поставки: в течение 20 календарных дней с даты заключения контракта
Условия оплаты: в течение 7 рабочих дней после приемки товара
Гарантийный срок: 24 месяца с даты передачи товара
</pre></main>''')
        content(page, 'extractor.js')
        actual = page.evaluate('window.__tendernotesExtractPage()')
        assert actual['number'] == NUMBER, actual
        assert actual['title'] == 'Поставка компьютерного оборудования', actual
        assert actual['deadline'] == '30.10.2026 09:15', actual
        assert actual['auction_date'] == '02.11.2026 10:30', actual
        assert actual['results_date'] == '03.11.2026', actual
        assert actual['due_days'] == 20 and actual['due_unit'] == 'calendar', actual
        assert '7 рабочих дней' in actual['payment_terms'], actual
        assert actual['warranty'].startswith('24 месяца'), actual
        page.locator('pre').evaluate("el => el.innerText='Срок поставки: в течение 20 календарных дней с даты заявки заказчика'")
        actual = page.evaluate('window.__tendernotesExtractPage()')
        assert actual['due_days'] is None, actual
        page.locator('pre').evaluate("el => el.innerText='Срок поставки: в течение 20 календарных дней с даты заявки заказчика. Контракт действует с даты заключения контракта.'")
        actual = page.evaluate('window.__tendernotesExtractPage()')
        assert actual['due_days'] is None, actual

        page.goto(BASE + 'documents.html?regNumber=' + NUMBER)
        page.set_content('''<h2>Извещение, изменение извещения о проведении закупки</h2>
<section><b>Действующая</b><div>Прикрепленные файлы</div>
<a href="/44fz/filestore/public/contract.docx">Проект контракта.docx</a>
<a href="/44fz/filestore/public/tz.pdf">Техническое задание.pdf</a>
<a href="/44fz/filestore/public/tz.pdf">Техническое задание.pdf</a>
<a href="/44fz/filestore/public/listModal.html?fileId=1">Сведения о подписи</a></section>
<section><b>Архивная</b><div>Прикрепленные файлы</div>
<a href="/44fz/filestore/public/old.docx">Старая редакция.docx</a></section>
<h2>Разъяснения положений документации</h2>
<a href="/44fz/filestore/public/clarification.docx">Разъяснение.docx</a>''')
        content(page, 'document_collector.js')
        actual = page.evaluate('window.__tnDiscoverDocuments()')
        assert actual['scope_ok'] and actual['current_revision_only'], actual
        assert len(actual['direct_links']) == 2, actual
        assert {v['title'] for v in actual['direct_links']} == {'Проект контракта.docx', 'Техническое задание.pdf'}, actual
        assert actual['auxiliary_skipped'] == 1, actual
        page.set_content('<h2>Документы</h2><a href="/contract.pdf">Контракт.pdf</a>')
        actual = page.evaluate('window.__tnDiscoverDocuments()')
        assert not actual['scope_ok'] and not actual['direct_links'], actual

        page.goto(BASE + 'common-info.html?regNumber=' + NUMBER)
        page.set_content('''<h2>Информация об объекте закупки</h2>
<table><tr><td>26.20.15.000-00000037</td><td>Системный блок</td><td>шт</td><td>10</td><td>50000</td><td>500000</td></tr></table>
<table><tr><th>Наименование характеристики</th><th>Значение характеристики</th><th>Единица измерения</th><th>Инструкция по заполнению</th></tr>
<tr><td>Объем оперативной памяти</td><td>32</td><td>ГБ</td><td>Значение характеристики не может изменяться</td></tr>
<tr><td>Требования к BIOS</td><td>UEFI</td><td></td><td>Значение характеристики не может изменяться</td></tr></table>''')
        content(page, 'eis_characteristics.js')
        actual = page.evaluate('window.__tnCollectEisEmbeddedSpec()')
        assert actual['found_section'] and actual['found_table'], actual
        assert len(actual['positions']) == 1 and actual['positions'][0]['quantity'] == '10', actual
        assert any(v['name'] == 'Объем оперативной памяти' and v['value'] == '32' for v in actual['rows']), actual
        assert any(v['name'] == 'Требования к BIOS' and v['value'] == 'UEFI' for v in actual['rows']), actual
        browser.close()
    print('Extension DOM PASS: dates/time, delivery anchor, payment, warranty, current-revision documents, deduplication, missing scope, KTRU/BIOS table')


if __name__ == '__main__':
    main()
