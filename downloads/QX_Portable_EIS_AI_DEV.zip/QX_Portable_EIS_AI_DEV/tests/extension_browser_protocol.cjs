// Exercise the shipped extension functions with Chrome APIs mocked explicitly.
// These checks do not claim that Edge loaded the unpacked extension or EIS is reachable.
const fs=require('fs'), vm=require('vm'), assert=require('assert/strict'), path=require('path');
const {webcrypto}=require('crypto');
const root=path.resolve(__dirname,'..','browser_extension');
const number='0325100013726000029';
function extract(text){
  const context=vm.createContext({URL,window:{},location:{href:`https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber=${number}`},
    document:{body:{innerText:text},title:'ЕИС',querySelector:()=>null,querySelectorAll:()=>[]}});
  vm.runInContext(fs.readFileSync(path.join(root,'extractor.js'),'utf8'),context);
  return context.window.__tendernotesExtractPage();
}
async function main(){
  const fields=extract(`Наименование объекта закупки: Поставка системных блоков для школы\nЗаказчик: МБУ Тестовый заказчик\nНачальная цена контракта: 1 200 000,50\nДата и время окончания подачи заявок: 20.11.2026 10:30\nДата проведения аукциона: 23.11.2026 12:00\nСрок поставки товара: в течение 20 рабочих дней с даты заключения контракта\nУсловия оплаты: в течение 7 рабочих дней после приемки товара\nМесто поставки: г. Москва, улица Тестовая, 5`);
  assert.equal(fields.number,number);assert.equal(fields.deadline,'20.11.2026 10:30');
  assert.equal(fields.auction_date,'23.11.2026 12:00');assert.equal(fields.due_days,20);assert.equal(fields.due_unit,'work');
  assert.match(fields.payment_terms,/7 рабочих дней/);assert.match(fields.place,/Тестовая/);
  assert.equal(extract('Срок поставки товара: в течение 5 рабочих дней после заявки заказчика').due_days,null);
  assert.equal(extract('Срок поставки товара: в течение 20 календарных дней с даты заявки заказчика. Контракт действует с даты заключения контракта').due_days,null);
  const quotation=extract('Закон: 44-ФЗ\nСпособ определения поставщика: Запрос котировок в электронной форме\nДата и время окончания подачи заявок: 31.12.2026 01:30 (МСК)');
  assert.equal(quotation.law,'44-ФЗ');assert.equal(quotation.is_quotation,true);assert.equal(quotation.deadline_timezone,'МСК');
  const uploaded=[],bytes=new TextEncoder().encode('Тестовый документ. Оплата в течение 7 рабочих дней.');
  const noop=()=>{};
  const chrome={runtime:{getURL:x=>'extension://'+x,getManifest:()=>({version:'1.16.0'}),onStartup:{addListener:noop},onInstalled:{addListener:noop},onMessage:{addListener:noop}},
    alarms:{create:noop,onAlarm:{addListener:noop}},action:{setBadgeText:noop,setBadgeBackgroundColor:noop,onClicked:{addListener:noop}},storage:{local:{get:async()=>({}),set:async()=>{}}}};
  const fetchMock=async url=>{
    if(url.startsWith('extension://'))return {ok:true,json:async()=>({token:'a'.repeat(43)})};
    return {ok:true,status:200,url,headers:new Headers({'content-type':'text/plain','content-disposition':"attachment; filename*=UTF-8''%D0%A2%D0%97.txt"}),body:new ReadableStream({start(c){c.enqueue(bytes);c.close();}})};
  };
  class WebSocket { static OPEN=1;static CONNECTING=0; constructor(){this.readyState=0;}addEventListener(){} }
  let context;
  const testSend=raw=>{const message=JSON.parse(raw);uploaded.push(message);setImmediate(()=>vm.runInContext(`pendingImports.get(${JSON.stringify(message.request_id)})({ok:true})`,context));};
  context=vm.createContext({chrome,fetch:fetchMock,crypto:webcrypto,URL,Headers,ReadableStream,TextDecoder,TextEncoder,Uint8Array,AbortController,WebSocket,
    setTimeout,clearTimeout,setInterval:noop,clearInterval:noop,btoa:x=>Buffer.from(x,'binary').toString('base64'),testSend});
  vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),context);
  await new Promise(setImmediate);
  vm.runInContext('socket={readyState:1,send:testSend};activeJobId="job-test";',context);
  const result=await vm.runInContext(`singleDownload('https://zakupki.gov.ru/44fz/filestore/download',1,'${number}','work','ТЗ','${'b'.repeat(40)}')`,context);
  assert.equal(result.file,'ТЗ.txt');assert.equal(uploaded.length,1);
  const message=uploaded[0];assert.equal(message.type,'file_upload');assert.equal(message.id,'job-test');
  assert.deepEqual(Buffer.from(message.data,'base64'),Buffer.from(bytes));
  assert.equal(message.sha256,require('crypto').createHash('sha256').update(bytes).digest('hex'));
  await assert.rejects(vm.runInContext("singleDownload('https://example.com/private',1,'x','x','x','x')",context),/только документы ЕИС/);
  console.log('Extension fixtures PASS: metadata dates/terms, relative-day anchor, browser bytes, SHA256, authenticated upload, foreign-host rejection.');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
