"""Execute the bundled worker's byte transfer using controlled browser APIs.

This is protocol validation, not installation of an extension or live EIS access.
"""
from pathlib import Path
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ExtensionWorkerBytes(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'), 'Node.js required for worker validation')
    def test_actual_worker_preserves_bytes_checksum_and_rejects_bad_responses(self):
        script = r"""
const assert = require('node:assert/strict');
const vm = require('node:vm');
const {readFileSync} = require('node:fs');
const {webcrypto, createHash} = require('node:crypto');
const noop={addListener(){}};
const data=Buffer.from('Срок поставки: 20 дней. BIOS UEFI.','utf8');
let mode='ok',uploaded=null;
const context={URL,AbortController,Uint8Array,TextDecoder,crypto:webcrypto,
  setTimeout,clearTimeout,setInterval,clearInterval,btoa,console,
  WebSocket:{OPEN:1,CONNECTING:0},
  chrome:{runtime:{getURL:n=>'chrome-extension://test/'+n,getManifest:()=>({version:'test'}),onMessage:noop,onStartup:noop,onInstalled:noop},
    storage:{local:{get:async()=>({}),set:async()=>{}}},
    alarms:{create(){},onAlarm:noop},action:{setBadgeText(){},setBadgeBackgroundColor(){},onClicked:noop}},
  fetch:async url=>{
    if(url.startsWith('chrome-extension:'))return {ok:true,json:async()=>({})};
    if(mode==='http-error')return {ok:false,status:403};
    return {ok:true,url:mode==='redirect'?'https://example.com/file.txt':url,
      headers:new Headers({'content-type':mode==='html'?'text/html':mode==='long'?'application/octet-stream':'text/plain',
        'content-disposition':"attachment; filename*=UTF-8''"+(mode==='long'?encodeURIComponent('Техническое задание '.repeat(12)+'.doc'):'%D0%A2%D0%97.txt'),
        'content-length':mode==='large'?String(31*1024*1024):String(data.length)}),
      body:new ReadableStream({start(controller){controller.enqueue(new Uint8Array(data));controller.close();}})};
  }};
vm.createContext(context);
vm.runInContext(readFileSync('browser_extension/background.js','utf8'),context);
(async()=>{
  await new Promise(r=>setTimeout(r,0));
  context.deliver = raw=>{
    const message=JSON.parse(raw); uploaded=message;
    context.ack={type:'file_import_result',request_id:message.request_id,ok:true};
    vm.runInContext('pendingImports.get(ack.request_id)(ack)',context);
  };
  vm.runInContext("socket={readyState:1,send:raw=>deliver(raw)};activeJobId='job';paired=true;",context);
  const call=()=>vm.runInContext("singleDownload('https://zakupki.gov.ru/44fz/filestore/public/1',1,'0325100013726000029',10,'Документ','claim')",context);
  const result=await call();
  assert.equal(result.file,'ТЗ.txt');
  assert.equal(Buffer.from(uploaded.data,'base64').toString('hex'),data.toString('hex'));
  assert.equal(uploaded.sha256,createHash('sha256').update(data).digest('hex'));
  assert.equal(uploaded.claim_token,'claim');
  assert.equal(uploaded.id,'job');
  mode='long';const long=await call();assert.equal(long.file.length,110);assert.ok(long.file.endsWith('.doc'));
  for (const [value,expected] of [['html',/страницу/],['large',/30 МБ/],['redirect',/пределы ЕИС/],['http-error',/403/]]) {
    mode=value;await assert.rejects(call(),expected);
  }
  await assert.rejects(vm.runInContext("singleDownload('https://example.com/file.txt',1,'n',10,'file','c')",context),/только документы ЕИС/);
  console.log('worker byte transfer PASS');
})().catch(e=>{console.error(e);process.exitCode=1;});
"""
        result = subprocess.run(['node', '-e', script], cwd=ROOT, capture_output=True,
                                text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('worker byte transfer PASS', result.stdout)


if __name__ == '__main__':
    unittest.main()
