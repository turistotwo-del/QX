"""Offline-only checks for QX AI integration; never downloads a vendor executable/model."""
from __future__ import annotations
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile
import unittest
import re

from modern import ollama_boot
from modern import model_install

ROOT = Path(__file__).resolve().parents[1]


class TestAutomaticAIInstallation(unittest.TestCase):
    def test_portable_and_in_app_installers_accept_the_same_pinned_model(self):
        script = (ROOT / 'portable' / 'auto_ai.ps1').read_text(encoding='utf-8-sig')
        revision = re.search(r"\$modelRevision = '([^']+)'", script).group(1)
        digest = re.search(r"\$modelSha256 = '([^']+)'", script).group(1)
        size = int(re.search(r'\$modelBytes = (\d+)L', script).group(1))
        self.assertEqual(revision, model_install.MODEL_REVISION)
        self.assertEqual(digest, model_install.MODEL_SHA256)
        self.assertEqual(size, model_install.MODEL_BYTES)
        self.assertNotIn('/resolve/main/', script)
        self.assertRegex(script, r"\$modelUrl = .*\+ \$modelRevision \+")
        check = script.split('function Check-Model', 1)[1].split('function Download-Engine', 1)[0]
        self.assertIn('$file.Length -ne $modelBytes', check)
        self.assertIn('Get-FileHash -LiteralPath $path -Algorithm SHA256', check)
        self.assertIn('return $hash -eq $modelSha256', check)
        download = script.split('function Download-Model', 1)[1].split('\ntry {', 1)[0]
        self.assertLess(download.index('Check-Model $tempModel'), download.index('Move-Item'))
        # The same verifier runs for reuse, even with an existing ready marker.
        self.assertLess(script.index('$modelVerified = Check-Model $modelFile'), script.index('AI Lite уже установлен.'))

    def test_official_engine_is_pinned_and_verified_before_launch(self):
        script = (ROOT / 'portable' / 'auto_ai.ps1').read_text(encoding='utf-8-sig')
        self.assertIn('https://github.com/ggml-org/llama.cpp/releases/download/b11815/', script)
        self.assertIn('asset.digest', script)
        self.assertLess(script.index('Get-FileHash'), script.index('Expand-Archive'))
        self.assertIn('qwen2.5-1.5b-instruct-q4_k_m.gguf', script)
        self.assertIn('Download-Model', script)
        self.assertIn('Check-Model', script)
        self.assertIn('lite-engine', script)
        self.assertIn('exit 0', script)  # Failed AI installation cannot kill QX startup.

    def test_portable_launcher_installs_once_and_preserves_app_data(self):
        script=(ROOT/'portable'/'start_qx.ps1').read_text(encoding='utf-8-sig')
        self.assertIn('qx-lite-1.5b.ready', script)
        self.assertIn("'auto_ai.ps1'", script)
        self.assertIn('QX_DISABLE_AUTO_AI', script)
        self.assertIn("$env:QX_DATA_DIR = Join-Path $env:LOCALAPPDATA 'QXPodborshchik'",script)

    def test_native_installer_provisions_ai_before_first_run(self):
        script=(ROOT/'windows_build'/'QX_Setup.iss').read_text(encoding='utf-8')
        self.assertIn('Source: "..\\portable\\auto_ai.ps1"', script)
        self.assertIn('skipifsilent', script)  # No multi-GB download in unattended CI.
        self.assertLess(script.index('Description: "Установить локальную нейросеть QX AI"'),script.index('Description: "Запустить QX Подборщик"'))

    def test_existing_ollama_never_spawned_or_stopped_by_qx(self):
        with patch.object(ollama_boot.sys, 'platform', 'win32'), patch.object(ollama_boot, 'ollama_reachable', return_value=True), \
             patch.object(ollama_boot.subprocess, 'Popen') as popen:
            proc = ollama_boot.start_ollama()
            self.assertIsNone(proc)
            popen.assert_not_called()

    def test_qx_owned_process_stops_on_shutdown(self):
        proc=MagicMock()
        proc.poll.return_value=None
        ollama_boot.stop_ollama(proc)
        proc.terminate.assert_called_once_with()
        proc.wait.assert_called_once_with(timeout=5)

    def test_no_ai_download_during_app_start(self):
        with patch.object(ollama_boot.sys, 'platform', 'win32'), patch.object(ollama_boot, 'ollama_reachable', return_value=False), \
             patch.object(ollama_boot, 'runtime_candidates', return_value=()), \
             patch.object(ollama_boot.subprocess,'Popen') as popen:
            self.assertIsNone(ollama_boot.start_ollama())
            popen.assert_not_called()

    def test_qx_ai_model_auto_selected_in_ui(self):
        from js_model_selection import select_models
        # Keep a deliberate installed-model selection; replace a missing model.
        models=['gguf:chosen.gguf','qx-lite:1.5b']
        self.assertEqual(select_models(models,'gguf:chosen.gguf')['tzAiModel'],'gguf:chosen.gguf')
        self.assertEqual(select_models(models,'removed:model')['tzAiModel'],'qx-lite:1.5b')

if __name__ == '__main__': unittest.main()
