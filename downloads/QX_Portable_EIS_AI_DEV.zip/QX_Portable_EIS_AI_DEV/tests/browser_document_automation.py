"""Real HTTP uploads/background analysis/UI, with local model absence controlled.

This checks in-app automation and editor preservation; it does not claim a live
EIS download or real LLM inference.
"""
from contextlib import contextmanager
from io import BytesIO
import base64
import hashlib
import os
from pathlib import Path
import tempfile
from threading import Event
from unittest.mock import patch

os.environ['QX_OFFLINE_MODE'] = '1'
_DATA = tempfile.TemporaryDirectory(prefix='qx_automation_browser_')
os.environ['QX_DATA_DIR'] = _DATA.name
os.environ['QX_PORTABLE_DATA_DIR'] = _DATA.name + '/userdata'
os.environ['QX_CATALOG_DIR'] = _DATA.name + '/catalog'

import httpx
from docx import Document
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
from chromium_launch import launch_chromium
from modern.server import app
from modern.start import _start_loopback_server
from modern import document_ai, extension_bridge


@contextmanager
def server():
    running, thread, listener, url = _start_loopback_server(app)
    try:
        yield url.rstrip('/')
    finally:
        running.should_exit = True
        thread.join(5)
        listener.close()
        extension_bridge.bridge.stop()
        assert not thread.is_alive()


def main():
    gate = Event()
    original_scan = document_ai.scan_document_facts
    def paused_scan(docs):
        if not gate.wait(20):
            raise RuntimeError('Browser test did not release background scan')
        return original_scan(docs)
    no_models = {'available':False, 'models':[], 'message':'Модель не установлена (контрольный сценарий)'}
    with patch('modern.local_ai.available_models', return_value=no_models), patch('modern.document_ai.scan_document_facts', side_effect=paused_scan), server() as url, httpx.Client(base_url=url, trust_env=False) as api, sync_playwright() as pw:
        card = api.post('/api/tenders', json={'number':'0325100013726000029','title':'Автоматизация документов','warranty':'48 месяцев'}).json()['tender']
        browser = launch_chromium(pw)
        page = browser.new_page(viewport={'width':1440,'height':1050})
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(url)
        page.locator(f'.qx-dashboard-tender[data-id="{card["id"]}"]').click()
        page.locator('[data-action="tender-extension-import"]').wait_for()
        page.locator('[data-action="tender-extension-open"]').click()
        page.locator('#qx-extension-progress .warning').wait_for()
        assert 'Edge' in page.locator('#qx-extension-progress').inner_text()
        page.locator('[data-action="tender-detail-tab"][data-view="docs"]').click()
        doc=Document()
        for line in (
            'Срок поставки: в течение 25 рабочих дней со дня заключения Контракта.',
            'Место поставки: Нижегородская область, г. Нижний Новгород, ул. Ленина, д. 5.',
            'Гарантийный срок: 24 месяца с даты подписания акта приёмки.',
            'Оплата в течение 7 рабочих дней после подписания документа о приёмке.',
            'Требуется российский реестровый BIOS, включённый в реестр российского программного обеспечения.'
        ): doc.add_paragraph(line)
        payload=BytesIO();doc.save(payload)
        page.locator('#file-tender').set_input_files({'name':'Contract.docx','mimeType':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','buffer':payload.getvalue()})
        page.wait_for_function("document.querySelector('.tender-doc-list')?.textContent.includes('Contract.docx')")
        page.locator('[data-action="tender-detail-tab"][data-view="comments"]').click()
        editor=page.locator('#tender-comment')
        editor.fill('Несохранённое поручение — не терять при фоновом анализе')
        gate.set()
        page.wait_for_function("document.querySelector('#qx-document-ai-progress')?.textContent.includes('Автоматический анализ завершён')",timeout=15000)
        assert editor.input_value() == 'Несохранённое поручение — не терять при фоновом анализе'
        assert editor.evaluate('(e)=>document.activeElement === e')
        page.locator('[data-action="tender-detail-tab"][data-view="docs"]').click()
        page.locator('#qx-document-ai-progress').wait_for()
        page.wait_for_function("document.querySelector('#qx-document-ai-progress')?.textContent.includes('не ответ нейросети')")
        report=page.locator('#qx-document-ai-progress').inner_text()
        assert 'Contract.docx' in report
        assert 'BIOS' in report
        assert 'Автозаполнено' in report
        assert 'Расхождений' in report
        current=api.get('/api/tenders/'+card['id']).json()['tender']
        assert current['due_days'] == 25 and current['due_unit'] == 'work'
        assert current['warranty'] == '48 месяцев'
        assert '7 рабочих дней' in current['payment_terms']
        page.locator('[data-action="tender-detail-tab"][data-view="contract"]').click()
        page.wait_for_function("Array.from(document.querySelectorAll('[data-tender-field=due_days]')).some(e=>e.value==='25')")
        # Controlled extension transport exercises the real local bridge and UI
        # progress/card refresh. It is deliberately not a live EIS claim.
        with TestClient(extension_bridge.bridge.app) as bridge_client, bridge_client.websocket_connect('/', headers={'origin':'chrome-extension://'+'a'*32}) as ws:
            ws.send_json({'type':'hello','token':extension_bridge.pairing_token(),'version':'browser-fixture'})
            assert ws.receive_json()['type'] == 'paired'
            page.locator('[data-action="tender-detail-tab"][data-view="overview"]').click()
            page.locator('[data-action="tender-extension-import"]').click()
            command=ws.receive_json()
            assert command['number'] == card['number']
            jid=command['id']
            ws.send_json({'type':'snapshot','id':jid,'data':{'number':card['number'],'url':command['url'],'deadline':'14.12.2026 10:30','auction_date':'16.12.2026 09:00'}})
            file_url='https://zakupki.gov.ru/44fz/filestore/public/1.0/download/priz/file?uid=ui-fixture'
            ws.send_json({'type':'file_claim','id':jid,'request_id':'claim-ui','url':file_url})
            decision=ws.receive_json()['decision']
            assert decision['action'] == 'download'
            blob='Приложение к закупке. Количество товара: 10 штук.'.encode()
            ws.send_json({'type':'file_upload','id':jid,'request_id':'upload-ui','url':file_url,'claim_token':decision['claim_token'],'filename':'Browser-source.txt','data':base64.b64encode(blob).decode(),'sha256':hashlib.sha256(blob).hexdigest()})
            assert ws.receive_json()['ok']
            ws.send_json({'type':'result','id':jid,'data':{'count_found':1,'errors':[]}})
            page.wait_for_function("document.querySelector('#qx-extension-progress')?.textContent.includes('Документы сохранены')",timeout=15000)
            assert 'сохранено: 1' in page.locator('#qx-extension-progress').inner_text()
            page.wait_for_function("Array.from(document.querySelectorAll('[data-tender-field=application_due_time]')).some(e=>e.value==='10:30')",timeout=15000)
            page.locator('[data-action="tender-detail-tab"][data-view="docs"]').click()
            page.wait_for_function("document.querySelector('.tender-doc-list')?.textContent.includes('Browser-source.txt')")
            saved=api.get('/api/tenders/'+card['id']).json()['tender']
            imported=next(d for d in saved['documents'] if d['filename']=='Browser-source.txt')
            assert api.get('/api/tenders/'+card['id']+'/documents/'+imported['id']).content == blob
        assert not errors, errors
        browser.close()
    print('Document automation PASS: real DOCX upload, background scan, citations, truthful no-model status, safe autofill, manual-value/editor preservation, Edge error guidance, paired extension fixture with SHA-256 file transfer and date/time UI refresh')


if __name__ == '__main__':
    try: main()
    finally: _DATA.cleanup()
