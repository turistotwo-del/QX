"""Real paired WebSocket protocol against SQLite; no live EIS claim."""
import base64
import hashlib
import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

os.environ.setdefault('QX_DATA_DIR', tempfile.mkdtemp(prefix='qx_extension_boot_'))
from modern import tender_store as store
from modern.extension_bridge import ExtensionBridge, merge_snapshot

NUMBER = '0325100013726000029'
URL = 'https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber=' + NUMBER
FILE_URL = 'https://zakupki.gov.ru/44fz/filestore/spec.txt'
ORIGIN = 'chrome-extension://' + 'a' * 32


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'APP_DATA', tmp_path)
    monkeypatch.setattr(store, 'DB_FILE', tmp_path / 'tenders.sqlite3')
    monkeypatch.setattr(store, 'DOCUMENTS', tmp_path / 'documents')
    monkeypatch.setattr(store, '_INITIALIZED', False)
    store.initialize()
    return ExtensionBridge()


def connect(client, bridge):
    context = client.websocket_connect('/', headers={'origin': ORIGIN})
    ws = context.__enter__()
    ws.send_json({'type': 'hello', 'token': bridge.pairing_token(), 'version': '1.16.0'})
    assert ws.receive_json() == {'type': 'paired'}
    return context, ws


def begin(bridge, ws, tender_id=''):
    job = bridge.start_job(NUMBER, tender_id)
    command = ws.receive_json()
    assert command['type'] == 'documents' and command['number'] == NUMBER
    return job['id']


def upload(ws, jid, data, *, name='spec.txt', digest=None, token=None, request='upload'):
    ws.send_json({'type': 'file_claim', 'id': jid, 'request_id': 'claim', 'url': FILE_URL})
    decision = ws.receive_json()['decision']
    assert decision['action'] == 'download'
    ws.send_json({'type': 'file_upload', 'id': jid, 'url': FILE_URL, 'request_id': request,
                  'claim_token': token or decision['claim_token'], 'filename': name,
                  'data': base64.b64encode(data).decode(),
                  'sha256': digest or hashlib.sha256(data).hexdigest()})
    return ws.receive_json()


def test_requires_extension_origin_and_correct_pairing(workspace):
    with TestClient(workspace.app) as client:
        for origin in ('https://zakupki.gov.ru', 'http://localhost', '', ORIGIN):
            with pytest.raises(WebSocketDisconnect):
                with client.websocket_connect('/', headers={'origin': origin}) as ws:
                    ws.send_json({'type': 'hello', 'token': 'incorrect'})
                    ws.receive_json()
    assert not workspace.status()['connected']


def test_token_persists_outside_checkout(workspace):
    token = workspace.pairing_token()
    assert ExtensionBridge().pairing_token() == token
    assert (store.APP_DATA / 'extension-pairing.token').stat().st_mode & 0o077 == 0


def test_browser_bytes_populate_card_preserve_edits_and_reject_conflicting_time(workspace):
    tender = store.create({'number': NUMBER, 'title': 'Ручное название',
                           'application_due_on': '2026-11-22', 'application_due_time': '10:00'})
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        try:
            jid = begin(workspace, ws, tender['id'])
            ws.send_json({'type': 'snapshot', 'id': jid, 'data': {
                'number': NUMBER, 'url': URL, 'title': 'Название из ЕИС',
                'customer': 'Тестовый заказчик', 'price': '1 250 000,50',
                'deadline': '21.11.2026 09:30', 'auction_date': '24.11.2026 12:45',
                'due_days': 20, 'due_unit': 'work', 'payment_terms': 'Оплата в течение 7 рабочих дней'}})
            data = 'Поставка в течение 20 рабочих дней. BIOS должен быть реестровым.'.encode()
            assert upload(ws, jid, data)['ok']
            with patch('modern.document_ai.submit', return_value={'state': 'queued'}) as analysis:
                ws.send_json({'type': 'result', 'id': jid, 'data': {'count_found': 1, 'errors': []}})
                # Claim roundtrip flushes the result handler before inspecting status.
                ws.send_json({'type': 'pong'})
                # The test client runs the actual ASGI task concurrently.
                import time
                deadline = time.monotonic() + 2
                while workspace.job_status(jid)['state'] not in ('complete', 'partial', 'failed') and time.monotonic() < deadline:
                    time.sleep(.005)
                job = workspace.job_status(jid)
                assert job['complete'] and job['imported'] == 1
                analysis.assert_called_once_with(tender['id'])
            current = store.detail(tender['id'])
            assert current['title'] == 'Ручное название'
            assert (current['application_due_on'], current['application_due_time']) == ('2026-11-22', '10:00')
            assert (current['auction_on'], current['auction_time']) == ('2026-11-24', '12:45')
            assert current['nmck'] == 1250000.5 and current['due_days'] == 20
            assert current['due_unit'] == 'work'
            assert store.document_bytes(tender['id'], current['documents'][0]['id'])[1] == data
            assert any('ЕИС через расширение' in event['label'] for event in current['events'])
            assert len(job['conflicts']) >= 2
        finally:
            context.__exit__(None, None, None)


def test_file_upload_validates_claim_hash_and_rejects_html(workspace):
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        try:
            jid = begin(workspace, ws)
            reply = upload(ws, jid, b'real text', digest='0' * 64)
            assert not reply['ok'] and 'сумма' in reply['error']
            # Claimed bytes cannot be replaced by a reported local file path.
            ws.send_json({'type': 'file_progress', 'id': jid, 'file': {'state': 'downloaded', 'file': '/etc/passwd'}})
            ws.send_json({'type': 'file_upload', 'id': jid, 'url': FILE_URL,
                          'claim_token': 'not-the-claim', 'request_id': 'bad', 'filename': 'test.txt', 'data': 'YWJj', 'sha256': '0' * 64})
            assert not ws.receive_json()['ok']
            assert store.detail(workspace.job_status(jid)['tender_id'])['documents'] == []
        finally:
            context.__exit__(None, None, None)


def test_foreign_notice_and_source_urls_never_fill_card(workspace):
    tender = store.create({'number': NUMBER})
    for snapshot in ({'number': NUMBER, 'url': URL.replace('zakupki.gov.ru', 'evilzakupki.gov.ru'), 'customer': 'wrong'},
                     {'number': '0' * 19, 'url': URL, 'customer': 'wrong'}):
        with pytest.raises(ValueError): merge_snapshot(tender['id'], snapshot, NUMBER)
    assert not store.get(tender['id'])['customer']
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        try:
            jid = begin(workspace, ws)
            ws.send_json({'type': 'file_claim', 'id': jid, 'request_id': 'x', 'url': 'https://example.com/private'})
            assert ws.receive_json()['decision']['action'] == 'denied'
        finally: context.__exit__(None, None, None)


def test_disconnect_reports_incomplete_and_keeps_saved_documents(workspace):
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        jid = begin(workspace, ws)
        assert upload(ws, jid, b'Source document')['ok']
        context.__exit__(None, None, None)
    job = workspace.job_status(jid)
    assert job['state'] == 'partial' and not job['complete']
    assert job['errors'] and len(store.detail(job['tender_id'])['documents']) == 1


def test_html_challenge_and_bad_signature_are_rejected(workspace):
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        try:
            jid = begin(workspace, ws)
            assert not upload(ws, jid, b'<!doctype html><html>captcha</html>')['ok']
        finally: context.__exit__(None, None, None)


def test_import_retry_deduplicates_bytes_and_never_claims_missing_files_complete(workspace):
    with TestClient(workspace.app) as client:
        context, ws = connect(client, workspace)
        try:
            jid = begin(workspace, ws)
            assert upload(ws, jid, b'Source bytes')['ok']
            # Receiving the next command proves processing of the result ended.
            ws.send_json({'type': 'result', 'id': jid, 'data': {'count_found': 2, 'errors': ['Второй файл недоступен']}})
            import time
            deadline = time.monotonic() + 2
            while workspace.job_status(jid)['state'] not in ('partial', 'failed') and time.monotonic() < deadline: time.sleep(.005)
            first = workspace.job_status(jid)
            assert not first['complete'] and first['state'] == 'partial'
            second_id = begin(workspace, ws, first['tender_id'])
            assert upload(ws, second_id, b'Source bytes')['ok']
            assert workspace.job_status(second_id)['duplicates'] == 1
            assert len(store.detail(first['tender_id'])['documents']) == 1
        finally: context.__exit__(None, None, None)


def test_quotation_law_and_working_days_fill_together_preserving_manual_values(workspace):
    tender = store.create({'number': NUMBER})
    applied, conflicts, warnings = merge_snapshot(tender['id'], {
        'number': NUMBER, 'url': URL, 'law': '44-ФЗ', 'is_quotation': True,
        'procedure': 'Запрос котировок в электронной форме', 'due_days': 20, 'due_unit': 'work'}, NUMBER)
    current = store.get(tender['id'])
    assert current['law'] == '44-ФЗ' and current['is_quotation'] == 1
    assert current['due_days'] == 20 and current['due_unit'] == 'work'
    store.update(tender['id'], {'law': '223-ФЗ', 'due_days': 9, 'due_unit': 'calendar'})
    merge_snapshot(tender['id'], {'number': NUMBER, 'url': URL, 'law': '44-ФЗ', 'due_days': 20, 'due_unit': 'work'}, NUMBER)
    current = store.get(tender['id'])
    assert current['law'] == '223-ФЗ' and current['due_days'] == 9 and current['due_unit'] == 'calendar'


def test_explicit_timezone_converts_date_and_clock_together_with_audit(workspace):
    tender = store.create({'number': NUMBER})
    local = datetime(2026, 12, 31, 1, 30, tzinfo=timezone(timedelta(hours=3))).astimezone()
    snapshot = {'number': NUMBER, 'url': URL, 'deadline': '31.12.2026 01:30', 'deadline_timezone': 'МСК'}
    merge_snapshot(tender['id'], snapshot, NUMBER)
    current = store.detail(tender['id'])
    assert current['application_due_on'] == local.date().isoformat()
    assert current['application_due_time'] == local.strftime('%H:%M')
    assert any('2026-12-31 01:30 (МСК)' in e['label'] and 'местное время' in e['label'] for e in current['events'])
    # Date mismatch prevents a converted clock from attaching to a manual date.
    store.update(tender['id'], {'application_due_on': '2027-01-02', 'application_due_time': ''})
    merge_snapshot(tender['id'], snapshot, NUMBER)
    assert store.get(tender['id'])['application_due_time'] == ''
