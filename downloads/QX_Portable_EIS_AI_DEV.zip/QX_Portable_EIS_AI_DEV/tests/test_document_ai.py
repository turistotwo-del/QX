"""Automatic review exercises actual SQLite/parsers; model responses are isolated."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from modern import document_ai as ai, local_ai, tender_store as store
from modern.contract_autofill import extract

class ScanDocuments(unittest.TestCase):
    def test_mocked_local_inference_output_is_checked_against_source(self):
        blob='Срок поставки: 20 календарных дней с даты заключения контракта.\nОплата в течение 7 рабочих дней после приёмки.\nBIOS должен входить в реестр российского ПО.'.encode()
        reply=json.dumps({'facts':[
            {'topic':'payment','line':1,'quote':'Оплата в течение 7 рабочих дней после приёмки.'},
            {'topic':'bios','line':2,'quote':'BIOS должен входить в реестр российского ПО.'},
            {'topic':'payment','line':1,'quote':'Оплата производится авансом'},
            {'topic':'bios','line':0,'quote':'Срок поставки: 20 календарных дней'},
        ]},ensure_ascii=False)
        with patch.object(local_ai,'available_models',return_value={'models':[local_ai.LITE_MODEL]}),patch.object(local_ai,'_lite_answer',return_value=reply) as model:
            result=local_ai.scan_document_facts([('Контракт.txt',blob)])
        self.assertEqual(result['state'],'complete')
        self.assertTrue(result['attempted']);model.assert_called_once()
        self.assertEqual([x['topic'] for x in result['facts']],['payment','bios'])
        self.assertEqual(result['rejected'],2)
        self.assertIn('строка',result['facts'][0]['evidence']['location'])

    def test_no_model_is_truthfully_reported(self):
        with patch.object(local_ai,'available_models',return_value={'models':[]}):
            result=local_ai.scan_document_facts([('x.txt',b'data')])
        self.assertEqual(result['state'],'unavailable');self.assertFalse(result['attempted'])
        self.assertEqual(result['facts'],[])

    def test_rejected_model_output_is_not_reported_as_findings(self):
        reply=json.dumps({'facts':[{'topic':'payment','line':0,'quote':'Оплата авансом миллион рублей'}]})
        with patch.object(local_ai,'available_models',return_value={'models':[local_ai.LITE_MODEL]}),patch.object(local_ai,'_lite_answer',return_value=reply):
            result=local_ai.scan_document_facts([('x.txt','Оплата в течение 7 дней после приёмки.'.encode())])
        self.assertEqual(result['facts'],[]);self.assertEqual(result['rejected'],1)
        self.assertIn('подтверждённых цитат не получено',result['message'])

    def test_small_context_budget_is_combined_and_reported(self):
        text='\n'.join(('Поставка товара, оплата после приёмки, BIOS реестровый, гарантия и обеспечение. '+str(i)+' '+('Условие '*80)) for i in range(30))
        with patch.object(local_ai,'available_models',return_value={'models':[local_ai.LITE_MODEL]}),patch.object(local_ai,'_lite_answer',return_value='{"facts":[]}') as model:
            result=local_ai.scan_document_facts([('x.txt',text.encode())])
        self.assertTrue(result['source_truncated'])
        self.assertLess(len(model.call_args.args[0]),2800)
        self.assertLessEqual(result['segments_selected'],12)

    def test_model_failure_is_not_successful_ai(self):
        with patch.object(local_ai,'available_models',return_value={'models':[local_ai.LITE_MODEL]}),patch.object(local_ai,'_lite_answer',side_effect=RuntimeError('timeout')):
            result=local_ai.scan_document_facts([('x.txt','Оплата в течение 10 дней.'.encode())])
        self.assertEqual(result['state'],'error');self.assertTrue(result['attempted'])
        self.assertIn('timeout',result['message'])

    def test_delivery_trigger_is_not_converted_from_customer_order(self):
        result=extract([('Контракт.txt','Срок поставки: в течение 20 календарных дней с даты заявки заказчика. Договор вступает в силу с даты заключения контракта.'.encode())])
        self.assertNotIn('due_days',[x['field'] for x in result['verified']])

    def test_late_contradiction_is_not_hidden_by_preview_limit(self):
        lines=['Гарантийный срок: 24 месяца.']+['Прочие условия договора.']*12500+['Гарантийный срок: 36 месяцев.']
        result=extract([('Контракт.txt','\n'.join(lines).encode())])
        self.assertIn('warranty',result['disputed'])
        self.assertNotIn('warranty',[r['field'] for r in result['verified']])

    def test_exact_deadline_not_first_unrelated_date(self):
        result=extract([('Контракт.txt','Срок поставки по договору от 01.01.2026 — не позднее 20.12.2026.'.encode())])
        self.assertEqual({x['field']:x['value'] for x in result['verified']}['due_on'],'2026-12-20')

class AutomaticCard(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old=store.APP_DATA,store.DB_FILE,store.DOCUMENTS,store._INITIALIZED
        store.APP_DATA=Path(self.tmp.name);store.DB_FILE=store.APP_DATA/'tenders.sqlite3';store.DOCUMENTS=store.APP_DATA/'docs';store._INITIALIZED=False
        store.initialize()
        self.model=patch.object(ai,'scan_document_facts',return_value={'state':'unavailable','attempted':False,'facts':[],'model':None})
        self.model.start()
    def tearDown(self):
        self.model.stop();store.APP_DATA,store.DB_FILE,store.DOCUMENTS,store._INITIALIZED=self.old;self.tmp.cleanup()
    def add(self,tid,name,text):return store.add_document(tid,name,text.encode())
    def test_blank_fill_evidence_persistence_and_no_overwrite(self):
        t=store.create({'title':'Автоматизация','warranty':'36 месяцев'})
        self.add(t['id'],'Контракт.txt','Срок поставки: в течение 25 рабочих дней со дня заключения контракта.\nМесто поставки: Москва, улица Тестовая, дом 7.\nГарантийный срок: 24 месяца.\nОплата в течение 7 рабочих дней после подписания документа о приёмке.\nBIOS должен быть включён в реестр российского ПО.')
        result=ai.run(t['id'])
        self.assertIn('due_days',result['applied']);self.assertIn('payment_terms',result['applied'])
        self.assertEqual(store.get(t['id'])['due_days'],25)
        self.assertEqual(store.get(t['id'])['due_unit'],'work')
        self.assertEqual(store.get(t['id'])['warranty'],'36 месяцев')
        self.assertEqual(result['conflicts'][0]['field'],'warranty')
        self.assertIn('BIOS',result['analysis']['bios']['status'])
        self.assertEqual(ai.status(t['id'])['state'],'complete')
        self.assertEqual(ai.run(t['id'])['applied'],[])
    def test_conflicting_contracts_never_choose_random_deadline(self):
        t=store.create({'title':'Противоречие'})
        for number in (20,30):self.add(t['id'],f'Договор {number}.txt',f'Срок поставки: в течение {number} календарных дней со дня заключения контракта.')
        result=ai.run(t['id'])
        self.assertIn('due_days',result['disputed']);self.assertNotIn('due_days',result['applied'])
    def test_manual_change_during_inference_preserved(self):
        t=store.create({'title':'Ручная правка'})
        self.add(t['id'],'Контракт.txt','Оплата в течение 7 рабочих дней после приёмки.')
        def inference(docs):
            store.update(t['id'],{'payment_terms':'Предоплата согласована вручную'})
            return {'state':'complete','facts':[],'attempted':True}
        with patch.object(ai,'scan_document_facts',side_effect=inference):result=ai.run(t['id'])
        self.assertNotIn('payment_terms',result['applied'])
        self.assertEqual(store.get(t['id'])['payment_terms'],'Предоплата согласована вручную')
    def test_attachment_change_during_model_scan_defers_fill(self):
        t=store.create({'title':'Новая редакция'})
        self.add(t['id'],'Контракт.txt','Оплата в течение 7 рабочих дней после приёмки.')
        def inference(docs):
            self.add(t['id'],'Договор 2.txt','Оплата в течение 30 рабочих дней после приёмки.')
            return {'state':'complete','facts':[],'attempted':True}
        with patch.object(ai,'scan_document_facts',side_effect=inference):result=ai.run(t['id'])
        self.assertTrue(result['stale']);self.assertEqual(result['applied'],[])
    def test_damaged_attachment_blocks_automatic_fill(self):
        t=store.create({'title':'Повреждение'})
        did=self.add(t['id'],'Контракт.txt','Оплата в течение 7 рабочих дней после приёмки.')
        with store.connection() as con:row=con.execute('SELECT file_path FROM tender_documents WHERE id=?',(did,)).fetchone()
        Path(row['file_path']).write_bytes(b'corrupted')
        result=ai.run(t['id'])
        self.assertEqual(result['applied'],[]);self.assertTrue(result['errors'])
